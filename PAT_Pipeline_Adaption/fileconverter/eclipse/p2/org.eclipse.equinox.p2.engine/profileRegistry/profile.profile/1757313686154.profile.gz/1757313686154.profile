<?xml version='1.0' encoding='UTF-8'?>
<?profile version='1.0.0'?>
<profile id='profile' timestamp='1757313686154'>
  <properties size='6'>
    <property name='org.eclipse.equinox.p2.cache' value='C:\Users\admin\Downloads\fileconverter\eclipse'/>
    <property name='org.eclipse.update.install.features' value='true'/>
    <property name='org.eclipse.equinox.p2.roaming' value='false'/>
    <property name='org.eclipse.equinox.p2.environments' value='osgi.os=linux,osgi.arch=x86_64,osgi.ws=gtk,osgi.nl=en_US'/>
    <property name='org.eclipse.equinox.p2.installFolder' value='C:\Users\admin\Downloads\fileconverter\eclipse'/>
    <property name='eclipse.touchpoint.launcherName' value='eclipse'/>
  </properties>
  <units size='61'>
    <unit id='EventBFileConverter' version='1.0.0.202509081441' generation='2'>
      <update id='EventBFileConverter' range='[0.0.0,1.0.0.202509081441)' severity='0'/>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.name' value='EventBFileConverter'/>
      </properties>
      <provides size='4'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='EventBFileConverter' version='1.0.0.202509081441'/>
        <provided namespace='osgi.bundle' name='EventBFileConverter' version='1.0.0.202509081441'/>
        <provided namespace='osgi.identity' name='EventBFileConverter' version='1.0.0.202509081441'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='20'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='3.30.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.expressions' range='3.9.200'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.preferences' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.contenttype' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.resources' range='3.20.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.filesystem' range='1.10.200'/>
        <required namespace='osgi.bundle' name='org.eventb.core' range='3.7.0'/>
        <required namespace='osgi.bundle' name='org.rodinp.core' range='1.10.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.app' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.jobs' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.apache.felix.scr' range='2.2.6'/>
        <required namespace='osgi.bundle' name='org.eclipse.osgi.services' range='3.11.200'/>
        <required namespace='osgi.bundle' name='org.eclipse.osgi.util' range='3.7.300'/>
        <required namespace='osgi.bundle' name='de.prob.core' range='9.4.5'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.launcher' range='1.6.600'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            EventBFileConverter
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='EventBFileConverter.source' range='[1.0.0.202509081441,1.0.0.202509081441]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='EventBFileConverter' version='1.0.0.202509081441'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='zipped'>
            true
          </instruction>
          <instruction key='manifest'>
            Bundle-SymbolicName: EventBFileConverter;singleton:=true&#xA;Bundle-Version: 1.0.0.202509081441
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='a.jre.javase' version='17.0.0' singleton='false'>
      <provides size='256'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='a.jre.javase' version='17.0.0'/>
        <provided namespace='java.package' name='com.sun.jarsigner' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.java.accessibility.util' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.jdi' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.jdi.connect' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.jdi.connect.spi' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.jdi.event' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.jdi.request' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.management' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.net.httpserver' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.net.httpserver.spi' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.nio.file' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.nio.sctp' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.security.auth' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.security.auth.callback' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.security.auth.login' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.security.auth.module' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.security.jgss' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.source.doctree' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.source.tree' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.source.util' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.tools.attach' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.tools.attach.spi' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.tools.javac' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.tools.jconsole' version='0.0.0'/>
        <provided namespace='java.package' name='java.applet' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.color' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.datatransfer' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.desktop' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.dnd' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.event' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.font' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.geom' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.im' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.im.spi' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.image' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.image.renderable' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.print' version='0.0.0'/>
        <provided namespace='java.package' name='java.beans' version='0.0.0'/>
        <provided namespace='java.package' name='java.beans.beancontext' version='0.0.0'/>
        <provided namespace='java.package' name='java.io' version='0.0.0'/>
        <provided namespace='java.package' name='java.lang' version='0.0.0'/>
        <provided namespace='java.package' name='java.lang.annotation' version='0.0.0'/>
        <provided namespace='java.package' name='java.lang.constant' version='0.0.0'/>
        <provided namespace='java.package' name='java.lang.instrument' version='0.0.0'/>
        <provided namespace='java.package' name='java.lang.invoke' version='0.0.0'/>
        <provided namespace='java.package' name='java.lang.management' version='0.0.0'/>
        <provided namespace='java.package' name='java.lang.module' version='0.0.0'/>
        <provided namespace='java.package' name='java.lang.ref' version='0.0.0'/>
        <provided namespace='java.package' name='java.lang.reflect' version='0.0.0'/>
        <provided namespace='java.package' name='java.lang.runtime' version='0.0.0'/>
        <provided namespace='java.package' name='java.math' version='0.0.0'/>
        <provided namespace='java.package' name='java.net' version='0.0.0'/>
        <provided namespace='java.package' name='java.net.http' version='0.0.0'/>
        <provided namespace='java.package' name='java.net.spi' version='0.0.0'/>
        <provided namespace='java.package' name='java.nio' version='0.0.0'/>
        <provided namespace='java.package' name='java.nio.channels' version='0.0.0'/>
        <provided namespace='java.package' name='java.nio.channels.spi' version='0.0.0'/>
        <provided namespace='java.package' name='java.nio.charset' version='0.0.0'/>
        <provided namespace='java.package' name='java.nio.charset.spi' version='0.0.0'/>
        <provided namespace='java.package' name='java.nio.file' version='0.0.0'/>
        <provided namespace='java.package' name='java.nio.file.attribute' version='0.0.0'/>
        <provided namespace='java.package' name='java.nio.file.spi' version='0.0.0'/>
        <provided namespace='java.package' name='java.rmi' version='0.0.0'/>
        <provided namespace='java.package' name='java.rmi.dgc' version='0.0.0'/>
        <provided namespace='java.package' name='java.rmi.registry' version='0.0.0'/>
        <provided namespace='java.package' name='java.rmi.server' version='0.0.0'/>
        <provided namespace='java.package' name='java.security' version='0.0.0'/>
        <provided namespace='java.package' name='java.security.cert' version='0.0.0'/>
        <provided namespace='java.package' name='java.security.interfaces' version='0.0.0'/>
        <provided namespace='java.package' name='java.security.spec' version='0.0.0'/>
        <provided namespace='java.package' name='java.sql' version='0.0.0'/>
        <provided namespace='java.package' name='java.text' version='0.0.0'/>
        <provided namespace='java.package' name='java.text.spi' version='0.0.0'/>
        <provided namespace='java.package' name='java.time' version='0.0.0'/>
        <provided namespace='java.package' name='java.time.chrono' version='0.0.0'/>
        <provided namespace='java.package' name='java.time.format' version='0.0.0'/>
        <provided namespace='java.package' name='java.time.temporal' version='0.0.0'/>
        <provided namespace='java.package' name='java.time.zone' version='0.0.0'/>
        <provided namespace='java.package' name='java.util' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.concurrent' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.concurrent.atomic' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.concurrent.locks' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.function' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.jar' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.logging' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.prefs' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.random' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.regex' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.spi' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.stream' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.zip' version='0.0.0'/>
        <provided namespace='java.package' name='javax.accessibility' version='0.0.0'/>
        <provided namespace='java.package' name='javax.annotation.processing' version='0.0.0'/>
        <provided namespace='java.package' name='javax.crypto' version='0.0.0'/>
        <provided namespace='java.package' name='javax.crypto.interfaces' version='0.0.0'/>
        <provided namespace='java.package' name='javax.crypto.spec' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio.event' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio.metadata' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio.plugins.bmp' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio.plugins.jpeg' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio.plugins.tiff' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio.stream' version='0.0.0'/>
        <provided namespace='java.package' name='javax.lang.model' version='0.0.0'/>
        <provided namespace='java.package' name='javax.lang.model.element' version='0.0.0'/>
        <provided namespace='java.package' name='javax.lang.model.type' version='0.0.0'/>
        <provided namespace='java.package' name='javax.lang.model.util' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.loading' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.modelmbean' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.monitor' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.openmbean' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.relation' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.remote' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.remote.rmi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.timer' version='0.0.0'/>
        <provided namespace='java.package' name='javax.naming' version='0.0.0'/>
        <provided namespace='java.package' name='javax.naming.directory' version='0.0.0'/>
        <provided namespace='java.package' name='javax.naming.event' version='0.0.0'/>
        <provided namespace='java.package' name='javax.naming.ldap' version='0.0.0'/>
        <provided namespace='java.package' name='javax.naming.ldap.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.naming.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.net' version='0.0.0'/>
        <provided namespace='java.package' name='javax.net.ssl' version='0.0.0'/>
        <provided namespace='java.package' name='javax.print' version='0.0.0'/>
        <provided namespace='java.package' name='javax.print.attribute' version='0.0.0'/>
        <provided namespace='java.package' name='javax.print.attribute.standard' version='0.0.0'/>
        <provided namespace='java.package' name='javax.print.event' version='0.0.0'/>
        <provided namespace='java.package' name='javax.rmi.ssl' version='0.0.0'/>
        <provided namespace='java.package' name='javax.script' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.auth' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.auth.callback' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.auth.kerberos' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.auth.login' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.auth.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.auth.x500' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.cert' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.sasl' version='0.0.0'/>
        <provided namespace='java.package' name='javax.smartcardio' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sound.midi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sound.midi.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sound.sampled' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sound.sampled.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sql' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sql.rowset' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sql.rowset.serial' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sql.rowset.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.border' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.colorchooser' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.event' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.filechooser' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.plaf' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.plaf.basic' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.plaf.metal' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.plaf.multi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.plaf.nimbus' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.plaf.synth' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.table' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.text' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.text.html' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.text.html.parser' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.text.rtf' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.tree' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.undo' version='0.0.0'/>
        <provided namespace='java.package' name='javax.tools' version='0.0.0'/>
        <provided namespace='java.package' name='javax.transaction.xa' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.catalog' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.crypto' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.crypto.dom' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.crypto.dsig' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.crypto.dsig.dom' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.crypto.dsig.keyinfo' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.crypto.dsig.spec' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.datatype' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.namespace' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.parsers' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.stream' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.stream.events' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.stream.util' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.transform' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.transform.dom' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.transform.sax' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.transform.stax' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.transform.stream' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.validation' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.xpath' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.dynalink' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.dynalink.beans' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.dynalink.linker' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.dynalink.linker.support' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.dynalink.support' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.javadoc.doclet' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.jfr' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.jfr.consumer' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.jshell' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.jshell.execution' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.jshell.spi' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.jshell.tool' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.management.jfr' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.net' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.nio' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.nio.mapmode' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.security.jarsigner' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.swing.interop' version='0.0.0'/>
        <provided namespace='java.package' name='netscape.javascript' version='0.0.0'/>
        <provided namespace='java.package' name='org.ietf.jgss' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.bootstrap' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.css' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.events' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.html' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.ls' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.ranges' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.stylesheets' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.traversal' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.views' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.xpath' version='0.0.0'/>
        <provided namespace='java.package' name='org.xml.sax' version='0.0.0'/>
        <provided namespace='java.package' name='org.xml.sax.ext' version='0.0.0'/>
        <provided namespace='java.package' name='org.xml.sax.helpers' version='0.0.0'/>
        <provided namespace='java.package' name='sun.misc' version='0.0.0'/>
        <provided namespace='java.package' name='sun.reflect' version='0.0.0'/>
        <provided namespace='osgi.ee' name='OSGi/Minimum' version='1.0.0'/>
        <provided namespace='osgi.ee' name='OSGi/Minimum' version='1.1.0'/>
        <provided namespace='osgi.ee' name='OSGi/Minimum' version='1.2.0'/>
        <provided namespace='osgi.ee' name='JRE' version='1.0.0'/>
        <provided namespace='osgi.ee' name='JRE' version='1.1.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='1.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='1.1.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='1.2.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='1.3.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='1.4.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='1.5.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='1.6.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='1.7.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='1.8.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='9.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='10.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='11.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='12.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='13.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='14.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='15.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='16.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='17.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE/compact1' version='1.8.0'/>
        <provided namespace='osgi.ee' name='JavaSE/compact1' version='17.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE/compact2' version='1.8.0'/>
        <provided namespace='osgi.ee' name='JavaSE/compact2' version='17.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE/compact3' version='1.8.0'/>
        <provided namespace='osgi.ee' name='JavaSE/compact3' version='17.0.0'/>
      </provides>
      <touchpoint id='org.eclipse.equinox.p2.native' version='1.0.0'/>
    </unit>
    <unit id='de.prob.core' version='9.4.5.202504241508' generation='2'>
      <update id='de.prob.core' range='[0.0.0,9.4.5.202504241508)' severity='0'/>
      <properties size='5'>
        <property name='org.eclipse.equinox.p2.name' value='ProB Animator Core'/>
        <property name='org.eclipse.equinox.p2.provider' value='HHU Dusseldorf STUPS Group'/>
        <property name='maven-groupId' value='de.prob'/>
        <property name='maven-artifactId' value='de.prob.core'/>
        <property name='maven-version' value='9.4.5-SNAPSHOT'/>
      </properties>
      <provides size='103'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='de.prob.core' version='9.4.5.202504241508'/>
        <provided namespace='osgi.bundle' name='de.prob.core' version='9.4.5.202504241508'/>
        <provided namespace='java.package' name='com.thoughtworks.xstream' version='0.0.0'/>
        <provided namespace='java.package' name='com.thoughtworks.xstream.annotations' version='0.0.0'/>
        <provided namespace='java.package' name='com.thoughtworks.xstream.converters' version='0.0.0'/>
        <provided namespace='java.package' name='com.thoughtworks.xstream.converters.basic' version='0.0.0'/>
        <provided namespace='java.package' name='com.thoughtworks.xstream.converters.collections' version='0.0.0'/>
        <provided namespace='java.package' name='com.thoughtworks.xstream.converters.enums' version='0.0.0'/>
        <provided namespace='java.package' name='com.thoughtworks.xstream.converters.extended' version='0.0.0'/>
        <provided namespace='java.package' name='com.thoughtworks.xstream.converters.javabean' version='0.0.0'/>
        <provided namespace='java.package' name='com.thoughtworks.xstream.converters.reflection' version='0.0.0'/>
        <provided namespace='java.package' name='com.thoughtworks.xstream.core' version='0.0.0'/>
        <provided namespace='java.package' name='com.thoughtworks.xstream.core.util' version='0.0.0'/>
        <provided namespace='java.package' name='com.thoughtworks.xstream.io' version='0.0.0'/>
        <provided namespace='java.package' name='com.thoughtworks.xstream.io.binary' version='0.0.0'/>
        <provided namespace='java.package' name='com.thoughtworks.xstream.io.copy' version='0.0.0'/>
        <provided namespace='java.package' name='com.thoughtworks.xstream.io.json' version='0.0.0'/>
        <provided namespace='java.package' name='com.thoughtworks.xstream.io.naming' version='0.0.0'/>
        <provided namespace='java.package' name='com.thoughtworks.xstream.io.path' version='0.0.0'/>
        <provided namespace='java.package' name='com.thoughtworks.xstream.io.xml' version='0.0.0'/>
        <provided namespace='java.package' name='com.thoughtworks.xstream.io.xml.xppdom' version='0.0.0'/>
        <provided namespace='java.package' name='com.thoughtworks.xstream.mapper' version='0.0.0'/>
        <provided namespace='java.package' name='com.thoughtworks.xstream.persistence' version='0.0.0'/>
        <provided namespace='java.package' name='de.be4.classicalb.core.parser' version='0.0.0'/>
        <provided namespace='java.package' name='de.be4.classicalb.core.parser.analysis' version='0.0.0'/>
        <provided namespace='java.package' name='de.be4.classicalb.core.parser.analysis.checking' version='0.0.0'/>
        <provided namespace='java.package' name='de.be4.classicalb.core.parser.analysis.prolog' version='0.0.0'/>
        <provided namespace='java.package' name='de.be4.classicalb.core.parser.analysis.transforming' version='0.0.0'/>
        <provided namespace='java.package' name='de.be4.classicalb.core.parser.exceptions' version='0.0.0'/>
        <provided namespace='java.package' name='de.be4.classicalb.core.parser.lexer' version='0.0.0'/>
        <provided namespace='java.package' name='de.be4.classicalb.core.parser.node' version='0.0.0'/>
        <provided namespace='java.package' name='de.be4.classicalb.core.parser.parser' version='0.0.0'/>
        <provided namespace='java.package' name='de.be4.classicalb.core.preparser.analysis' version='0.0.0'/>
        <provided namespace='java.package' name='de.be4.classicalb.core.preparser.lexer' version='0.0.0'/>
        <provided namespace='java.package' name='de.be4.classicalb.core.preparser.node' version='0.0.0'/>
        <provided namespace='java.package' name='de.be4.classicalb.core.preparser.parser' version='0.0.0'/>
        <provided namespace='java.package' name='de.be4.ltl.core.ctlparser.analysis' version='0.0.0'/>
        <provided namespace='java.package' name='de.be4.ltl.core.ctlparser.lexer' version='0.0.0'/>
        <provided namespace='java.package' name='de.be4.ltl.core.ctlparser.node' version='0.0.0'/>
        <provided namespace='java.package' name='de.be4.ltl.core.ctlparser.parser' version='0.0.0'/>
        <provided namespace='java.package' name='de.be4.ltl.core.parser' version='0.0.0'/>
        <provided namespace='java.package' name='de.be4.ltl.core.parser.analysis' version='0.0.0'/>
        <provided namespace='java.package' name='de.be4.ltl.core.parser.internal' version='0.0.0'/>
        <provided namespace='java.package' name='de.be4.ltl.core.parser.lexer' version='0.0.0'/>
        <provided namespace='java.package' name='de.be4.ltl.core.parser.node' version='0.0.0'/>
        <provided namespace='java.package' name='de.be4.ltl.core.parser.parser' version='0.0.0'/>
        <provided namespace='java.package' name='de.hhu.stups.sablecc.patch' version='0.0.0'/>
        <provided namespace='java.package' name='de.prob.animator.domainobjects' version='0.0.0'/>
        <provided namespace='java.package' name='de.prob.cli' version='0.0.0'/>
        <provided namespace='java.package' name='de.prob.cli.clipatterns' version='0.0.0'/>
        <provided namespace='java.package' name='de.prob.core' version='0.0.0'/>
        <provided namespace='java.package' name='de.prob.core.command' version='0.0.0'/>
        <provided namespace='java.package' name='de.prob.core.command.internal' version='0.0.0'/>
        <provided namespace='java.package' name='de.prob.core.domainobjects' version='0.0.0'/>
        <provided namespace='java.package' name='de.prob.core.domainobjects.eval' version='0.0.0'/>
        <provided namespace='java.package' name='de.prob.core.domainobjects.ltl' version='0.0.0'/>
        <provided namespace='java.package' name='de.prob.core.internal' version='0.0.0'/>
        <provided namespace='java.package' name='de.prob.core.langdep' version='0.0.0'/>
        <provided namespace='java.package' name='de.prob.core.prolog' version='0.0.0'/>
        <provided namespace='java.package' name='de.prob.core.sablecc.analysis' version='0.0.0'/>
        <provided namespace='java.package' name='de.prob.core.sablecc.lexer' version='0.0.0'/>
        <provided namespace='java.package' name='de.prob.core.sablecc.node' version='0.0.0'/>
        <provided namespace='java.package' name='de.prob.core.sablecc.parser' version='0.0.0'/>
        <provided namespace='java.package' name='de.prob.core.translator' version='0.0.0'/>
        <provided namespace='java.package' name='de.prob.core.types' version='0.0.0'/>
        <provided namespace='java.package' name='de.prob.cosimulation' version='0.0.0'/>
        <provided namespace='java.package' name='de.prob.eventb.translator' version='0.0.0'/>
        <provided namespace='java.package' name='de.prob.eventb.translator.flow' version='0.0.0'/>
        <provided namespace='java.package' name='de.prob.eventb.translator.internal' version='0.0.0'/>
        <provided namespace='java.package' name='de.prob.exceptions' version='0.0.0'/>
        <provided namespace='java.package' name='de.prob.logging' version='0.0.0'/>
        <provided namespace='java.package' name='de.prob.model.eventb' version='0.0.0'/>
        <provided namespace='java.package' name='de.prob.model.representation' version='0.0.0'/>
        <provided namespace='java.package' name='de.prob.model.serialize' version='0.0.0'/>
        <provided namespace='java.package' name='de.prob.parser' version='0.0.0'/>
        <provided namespace='java.package' name='de.prob.parserbase' version='0.0.0'/>
        <provided namespace='java.package' name='de.prob.prolog.match' version='0.0.0'/>
        <provided namespace='java.package' name='de.prob.prolog.output' version='0.0.0'/>
        <provided namespace='java.package' name='de.prob.prolog.term' version='0.0.0'/>
        <provided namespace='java.package' name='de.prob.sap.commands' version='0.0.0'/>
        <provided namespace='java.package' name='de.prob.sap.exceptions' version='0.0.0'/>
        <provided namespace='java.package' name='de.prob.sap.util' version='0.0.0'/>
        <provided namespace='java.package' name='de.prob.unicode' version='0.0.0'/>
        <provided namespace='java.package' name='de.prob.unicode.analysis' version='0.0.0'/>
        <provided namespace='java.package' name='de.prob.unicode.lexer' version='0.0.0'/>
        <provided namespace='java.package' name='de.prob.unicode.node' version='0.0.0'/>
        <provided namespace='java.package' name='javax.annotation' version='0.0.0'/>
        <provided namespace='java.package' name='javax.annotation.concurrent' version='0.0.0'/>
        <provided namespace='java.package' name='javax.annotation.meta' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.commons.lang' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.commons.lang.builder' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.commons.lang.enums' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.commons.lang.exception' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.commons.lang.math' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.commons.lang.mutable' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.commons.lang.reflect' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.commons.lang.text' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.commons.lang.time' version='0.0.0'/>
        <provided namespace='java.package' name='org.ptolemy.fmi' version='0.0.0'/>
        <provided namespace='java.package' name='org.ptolemy.fmi.driver' version='0.0.0'/>
        <provided namespace='java.package' name='org.ptolemy.fmi.type' version='0.0.0'/>
        <provided namespace='osgi.identity' name='de.prob.core' version='9.4.5.202504241508'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='9'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.filesystem' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.rodinp.core' range='[1.7.0,2.0.0)'/>
        <required namespace='osgi.bundle' name='org.eventb.theory.core' range='[4.0.0,4.1.0)' optional='true' greedy='false'/>
        <required namespace='osgi.bundle' name='org.eventb.core.ast' range='[3.3.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.resources' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eventb.core.seqprover' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eventb.core' range='[3.3.0,4.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='de.prob.core' version='9.4.5.202504241508'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='zipped'>
            true
          </instruction>
          <instruction key='manifest'>
            Bundle-SymbolicName: de.prob.core;singleton:=true&#xA;Bundle-Version: 9.4.5.202504241508
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='eventbfileconverter.product' version='1.0.0.202509081441'>
      <update id='eventbfileconverter.product' range='0.0.0' severity='0'/>
      <properties size='3'>
        <property name='org.eclipse.equinox.p2.name' value='EventB File Converter'/>
        <property name='org.eclipse.equinox.p2.type.product' value='true'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
      </properties>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='eventbfileconverter.product' version='1.0.0.202509081441'/>
      </provides>
      <requires size='49'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osgi.util.promise' range='[1.3.0.202212101352,1.3.0.202212101352]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.compatibility.state' range='[1.2.900.v20231106-0859,1.2.900.v20231106-0859]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eventb.core.ast' range='[3.8.0.202406100806-9b87fe13d,3.8.0.202406100806-9b87fe13d]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.upnp' range='[1.2.1.202109301733,1.2.1.202109301733]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.services' range='[3.11.200.v20231106-0901,3.11.200.v20231106-0901]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.util' range='[3.7.300.v20231104-1118,3.7.300.v20231104-1118]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eventb.core.seqprover' range='[3.7.0.202406100806-9b87fe13d,3.7.0.202406100806-9b87fe13d]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.resources' range='[3.20.0.v20231102-0934,3.20.0.v20231102-0934]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.wireadmin' range='[1.0.2.202109301733,1.0.2.202109301733]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.preferences' range='[3.10.400.v20231102-2218,3.10.400.v20231102-2218]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osgi.util.position' range='[1.0.1.201505202026,1.0.1.201505202026]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='EventBFileConverter' range='[1.0.0.202509081441,1.0.0.202509081441]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osgi.util.function' range='[1.2.0.202109301733,1.2.0.202109301733]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.prefs' range='[1.1.2.202109301733,1.1.2.202109301733]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.device' range='[1.1.1.202109301733,1.1.1.202109301733]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.gtk.linux.x86_64' range='[1.2.800.v20231003-1442,1.2.800.v20231003-1442]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='tooling.source.default' range='[1.0.0,1.0.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.equinox.launcher.gtk.linux.x86_64' range='[1.2.800.v20231003-1442,1.2.800.v20231003-1442]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi' range='[3.18.600.v20231110-1900,3.18.600.v20231110-1900]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.cm' range='[1.6.1.202109301733,1.6.1.202109301733]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osgi.util.xml' range='[1.0.2.202109301733,1.0.2.202109301733]'/>
        <required namespace='osgi.ee' name='JavaSE' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher' range='[1.6.600.v20231106-1826,1.6.600.v20231106-1826]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingeventbfileconverter.product_root.gtk.linux.x86_64' range='[1.0.0.202509081441,1.0.0.202509081441]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.registry' range='[3.11.400.v20231102-2218,3.11.400.v20231102-2218]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.app' range='[1.6.400.v20231103-0807,1.6.400.v20231103-0807]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.felix.scr' range='[2.2.6,2.2.6]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.jobs' range='[3.15.100.v20230930-1207,3.15.100.v20230930-1207]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='eventbfileconverter.product_root.gtk.linux.x86_64' range='[1.0.0.202509081441,1.0.0.202509081441]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.event' range='[1.4.1.202109301733,1.4.1.202109301733]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.rodinp.core' range='[1.10.0.202406100806-9b87fe13d,1.10.0.202406100806-9b87fe13d]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.common' range='[3.18.200.v20231106-1826,3.18.200.v20231106-1826]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.expressions' range='[3.9.200.v20230921-0857,3.9.200.v20230921-0857]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.fx.osgi' range='[3.9.0.202210162353,3.9.0.202210162353]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.equinox.launcher' range='[1.6.600.v20231106-1826,1.6.600.v20231106-1826]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.component' range='[1.5.1.202212101352,1.5.1.202212101352]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.provisioning' range='[1.2.0.201505202024,1.2.0.201505202024]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.useradmin' range='[1.1.1.202109301733,1.1.1.202109301733]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eventb.core' range='[3.7.0.202406100806-9b87fe13d,3.7.0.202406100806-9b87fe13d]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.linux.x86_64' range='[1.2.400.v20220812-1420,1.2.400.v20220812-1420]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='tooling.osgi.bundle.default' range='[1.0.0,1.0.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.contenttype' range='[3.9.200.v20230914-0751,3.9.200.v20230914-0751]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='de.prob.core' range='[9.4.5.202504241508,9.4.5.202504241508]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.runtime' range='[3.30.0.v20231102-0719,3.30.0.v20231102-0719]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingeventbfileconverter.product.configuration' range='[1.0.0.202509081441,1.0.0.202509081441]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osgi.util.measurement' range='[1.0.2.201802012109,1.0.2.201802012109]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='tooling.org.eclipse.update.feature.default' range='[1.0.0,1.0.0]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem' range='[1.10.200.v20231102-0934,1.10.200.v20231102-0934]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.metatype' range='[1.4.1.202109301733,1.4.1.202109301733]'/>
      </requires>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
    </unit>
    <unit id='eventbfileconverter.product_root.gtk.linux.x86_64' version='1.0.0.202509081441'>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='eventbfileconverter.product_root.gtk.linux.x86_64' version='1.0.0.202509081441'/>
      </provides>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
      </filter>
      <artifacts size='1'>
        <artifact classifier='binary' id='eventbfileconverter.product_root.gtk.linux.x86_64' version='1.0.0.202509081441'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.native' version='1.0.0'/>
      <touchpointData size='2'>
        <instructions size='2'>
          <instruction key='uninstall'>
            cleanupzip(source:@artifact, target:${installFolder});
          </instruction>
          <instruction key='install'>
            unzip(source:@artifact, target:${installFolder});
          </instruction>
        </instructions>
        <instructions size='1'>
          <instruction key='install'>
            chmod(targetDir:${installFolder}, targetFile:eclipse, permissions:755)
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.apache.felix.scr' version='2.2.6' singleton='false' generation='2'>
      <update id='org.apache.felix.scr' range='[0.0.0,2.2.6)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='Apache Felix Declarative Services'/>
        <property name='org.eclipse.equinox.p2.description' value='Implementation of the Declarative Services specification 1.5'/>
        <property name='org.eclipse.equinox.p2.provider' value='The Apache Software Foundation'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='http://felix.apache.org/site/apache-felix-service-component-runtime.html'/>
        <property name='maven-groupId' value='org.apache.felix'/>
        <property name='maven-artifactId' value='org.apache.felix.scr'/>
        <property name='maven-version' value='2.2.6'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.apache.felix.scr' version='2.2.6'/>
        <provided namespace='osgi.bundle' name='org.apache.felix.scr' version='2.2.6'/>
        <provided namespace='java.package' name='org.apache.felix.scr.component' version='1.1.0'/>
        <provided namespace='java.package' name='org.apache.felix.scr.info' version='1.0.0'/>
        <provided namespace='osgi.identity' name='org.apache.felix.scr' version='2.2.6'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='osgi.extender' name='osgi.component' version='1.5.0'/>
        <provided namespace='osgi.service' name='org.apache.felix.scr_2.2.6-2' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.osgi.service.component.runtime.ServiceComponentRuntime' type='List'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='21'>
        <required namespace='java.package' name='org.osgi.service.cm' range='[1.6.0,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.osgi.service.log' range='[1.4.0,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.osgi.service.metatype' range='[1.2.0,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.felix.service.command' range='[1.0.0,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.apache.felix.scr.component' range='[1.1.0,1.2.0)'/>
        <required namespace='java.package' name='org.apache.felix.scr.info' range='[1.0.0,1.1.0)'/>
        <required namespace='java.package' name='org.osgi.dto' range='[1.1.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.10.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework.dto' range='[1.8.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework.startlevel' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework.wiring' range='[1.2.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.resource' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.service.component' range='[1.5.0,1.6.0)'/>
        <required namespace='java.package' name='org.osgi.service.component.runtime' range='[1.5.0,1.6.0)'/>
        <required namespace='java.package' name='org.osgi.service.component.runtime.dto' range='[1.5.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.util.promise' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='[1.5.0,2.0.0)'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax.helpers' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(|(&amp;(osgi.ee=JavaSE)(version=1.7))(&amp;(osgi.ee=JavaSE/compact1)(version=1.8)))'>
          <description>
            org.apache.felix.scr
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.apache.felix.scr' version='2.2.6'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.apache.felix.scr&#xA;Bundle-Version: 2.2.6
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.contenttype' version='3.9.200.v20230914-0751' generation='2'>
      <update id='org.eclipse.core.contenttype' range='[0.0.0,3.9.200.v20230914-0751)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Eclipse Content Mechanism'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.core.contenttype'/>
        <property name='maven-version' value='3.9.200-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.contenttype' version='3.9.200.v20230914-0751'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.contenttype' version='3.9.200.v20230914-0751'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.content' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime.content' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.core.contenttype' version='3.9.200.v20230914-0751'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='12'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.preferences' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.13.0,4.0.0)'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax.ext' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax.helpers' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.core.contenttype
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.contenttype' version='3.9.200.v20230914-0751'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.contenttype; singleton:=true&#xA;Bundle-Version: 3.9.200.v20230914-0751
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.expressions' version='3.9.200.v20230921-0857' generation='2'>
      <update id='org.eclipse.core.expressions' range='[0.0.0,3.9.200.v20230921-0857)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Expression Language'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.core.expressions'/>
        <property name='maven-version' value='3.9.200-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='9'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.expressions' version='3.9.200.v20230921-0857'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.expressions' version='3.9.200.v20230921-0857'/>
        <provided namespace='java.package' name='org.eclipse.core.expressions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.expressions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.expressions.propertytester' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.expressions.util' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.core.expressions' version='3.9.200.v20230921-0857'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.29.0,4.0.0)'/>
        <required namespace='java.package' name='org.w3c.dom' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.core.expressions
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.expressions' version='3.9.200.v20230921-0857'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.expressions; singleton:=true&#xA;Bundle-Version: 3.9.200.v20230921-0857
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.filesystem' version='1.10.200.v20231102-0934' generation='2'>
      <update id='org.eclipse.core.filesystem' range='[0.0.0,1.10.200.v20231102-0934)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Core File Systems'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.core.filesystem'/>
        <property name='maven-version' value='1.10.200-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='10'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem' version='1.10.200.v20231102-0934'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.filesystem' version='1.10.200.v20231102-0934'/>
        <provided namespace='java.package' name='org.eclipse.core.filesystem' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.filesystem.provider' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.filesystem' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.filesystem.local' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.filesystem.local.unix' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.core.filesystem' version='1.10.200.v20231102-0934'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='5'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.18.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.osgi' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.29.0,4.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.core.filesystem
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.filesystem' version='1.10.200.v20231102-0934'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.filesystem; singleton:=true&#xA;Bundle-Version: 1.10.200.v20231102-0934
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.filesystem.linux.x86_64' version='1.2.400.v20220812-1420'>
      <update id='org.eclipse.core.filesystem.linux.x86_64' range='[0.0.0,1.2.400.v20220812-1420)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.fragmentName' value='Core File System for Linux'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%fragmentName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='fragment'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.core.filesystem.linux.x86_64'/>
        <property name='maven-version' value='1.2.400-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.linux.x86_64' version='1.2.400.v20220812-1420'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.filesystem.linux.x86_64' version='1.2.400.v20220812-1420'/>
        <provided namespace='osgi.identity' name='org.eclipse.core.filesystem.linux.x86_64' version='1.2.400.v20220812-1420'>
          <properties size='1'>
            <property name='type' value='osgi.fragment'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='osgi.fragment' name='org.eclipse.core.filesystem' version='1.2.400.v20220812-1420'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='osgi.bundle' name='org.eclipse.core.filesystem' range='[1.7.200,2.0.0)'/>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=linux))
      </filter>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.filesystem.linux.x86_64' version='1.2.400.v20220812-1420'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.filesystem.linux.x86_64; singleton:=true&#xA;Bundle-Version: 1.2.400.v20220812-1420&#xA;Fragment-Host: org.eclipse.core.filesystem;bundle-version=&quot;[1.7.200,2.0.0)&quot;
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.jobs' version='3.15.100.v20230930-1207' generation='2'>
      <update id='org.eclipse.core.jobs' range='[0.0.0,3.15.100.v20230930-1207)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Eclipse Jobs Mechanism'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.core.jobs'/>
        <property name='maven-version' value='3.15.100-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.jobs' version='3.15.100.v20230930-1207'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.jobs' version='3.15.100.v20230930-1207'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.jobs' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.jobs' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime.jobs' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.core.jobs' version='3.15.100.v20230930-1207'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='7'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.8.0,4.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.core.jobs
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.jobs' version='3.15.100.v20230930-1207'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.jobs; singleton:=true&#xA;Bundle-Version: 3.15.100.v20230930-1207
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.resources' version='3.20.0.v20231102-0934' generation='2'>
      <update id='org.eclipse.core.resources' range='[0.0.0,3.20.0.v20231102-0934)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Core Resource Management'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.core.resources'/>
        <property name='maven-version' value='3.20.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='24'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.resources' version='3.20.0.v20231102-0934'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.resources' version='3.20.0.v20231102-0934'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.dtree' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.events' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.localstore' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.properties' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.propertytester' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.refresh' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.resources' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.resources.mapping' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.resources.projectvariables' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.resources.refresh.win32' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.utils' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.watson' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.resources' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.resources.filtermatchers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.resources.mapping' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.resources.refresh' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.resources.team' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.resources.undo.snapshot' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.resources.variableresolvers' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.core.resources' version='3.20.0.v20231102-0934'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='6'>
        <required namespace='osgi.bundle' name='org.eclipse.ant.core' range='[3.1.0,4.0.0)' optional='true' greedy='false'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.expressions' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.filesystem' range='[1.3.0,2.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.29.0,4.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='[1.3.0,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.core.resources
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.resources' version='3.20.0.v20231102-0934'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.resources; singleton:=true&#xA;Bundle-Version: 3.20.0.v20231102-0934
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.runtime' version='3.30.0.v20231102-0719' generation='2'>
      <update id='org.eclipse.core.runtime' range='[0.0.0,3.30.0.v20231102-0719)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Core Runtime'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.core.runtime'/>
        <property name='maven-version' value='3.30.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.runtime' version='3.30.0.v20231102-0719'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.runtime' version='3.30.0.v20231102-0719'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.preferences.legacy' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.runtime' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime' version='3.7.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.core.runtime' version='3.30.0.v20231102-0719'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='8'>
        <required namespace='osgi.bundle' name='org.eclipse.osgi' range='[3.17.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.18.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.jobs' range='[3.13.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='[3.11.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.preferences' range='[3.10.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.contenttype' range='[3.8.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.app' range='1.6.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.core.runtime
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.runtime' version='3.30.0.v20231102-0719'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.runtime; singleton:=true&#xA;Bundle-Version: 3.30.0.v20231102-0719
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.app' version='1.6.400.v20231103-0807' generation='2'>
      <update id='org.eclipse.equinox.app' range='[0.0.0,1.6.400.v20231103-0807)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Equinox Application Container'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.equinox'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.app'/>
        <property name='maven-version' value='1.6.400-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.app' version='1.6.400.v20231103-0807'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.app' version='1.6.400.v20231103-0807'/>
        <provided namespace='java.package' name='org.eclipse.equinox.app' version='1.1.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.app' version='0.0.0'/>
        <provided namespace='java.package' name='org.osgi.service.application' version='1.1.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.app' version='1.6.400.v20231103-0807'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='16'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='[3.4.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.2.0,4.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.console' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.log' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.environment' range='1.1.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.runnable' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.storagemanager' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.condpermadmin' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.osgi.service.event' range='1.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='1.2.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'>
          <description>
            org.eclipse.equinox.app
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.app' version='1.6.400.v20231103-0807'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.app; singleton:=true&#xA;Bundle-Version: 1.6.400.v20231103-0807
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.common' version='3.18.200.v20231106-1826' generation='2'>
      <update id='org.eclipse.equinox.common' range='[0.0.0,3.18.200.v20231106-1826)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Common Eclipse Runtime'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.equinox'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.common'/>
        <property name='maven-version' value='3.18.200-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='10'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.common' version='3.18.200.v20231106-1826'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.common' version='3.18.200.v20231106-1826'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.boot' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.runtime' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime' version='3.7.0'/>
        <provided namespace='java.package' name='org.eclipse.core.text' version='3.13.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.events' version='1.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.common' version='3.18.200.v20231106-1826'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.osgi' range='[3.17.200,4.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'>
          <description>
            org.eclipse.equinox.common
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.common' version='3.18.200.v20231106-1826'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.common; singleton:=true&#xA;Bundle-Version: 3.18.200.v20231106-1826
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.event' version='1.6.300.v20231012-1251' singleton='false' generation='2'>
      <update id='org.eclipse.equinox.event' range='[0.0.0,1.6.300.v20231012-1251)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.bundleVendor' value='Eclipse.org - Equinox'/>
        <property name='df_LT.bundleName' value='Event Admin'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%bundleVendor'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.equinox'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.event'/>
        <property name='maven-version' value='1.6.300-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='9'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.event' version='1.6.300.v20231012-1251'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.event' version='1.6.300.v20231012-1251'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.event' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.event.mapper' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.event' version='1.6.300.v20231012-1251'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.equinox.event_1.6.300.v20231012-1251-1' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.osgi.service.event.EventAdmin' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.implementation' name='osgi.event' version='1.4.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='8'>
        <required namespace='java.package' name='org.eclipse.osgi.framework.eventmgr' range='1.1.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.6.0'/>
        <required namespace='java.package' name='org.osgi.service.event' range='[1.3.0,1.5.0)'/>
        <required namespace='java.package' name='org.osgi.service.log' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='1.5.0'/>
        <requiredProperties namespace='osgi.extender' match='(&amp;(osgi.extender=osgi.component)(version&gt;=1.0)(!(version&gt;=2.0)))'>
          <description>
            org.eclipse.equinox.event
          </description>
        </requiredProperties>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.eclipse.equinox.event
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.event' version='1.6.300.v20231012-1251'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.event&#xA;Bundle-Version: 1.6.300.v20231012-1251
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.launcher' version='1.6.600.v20231106-1826' generation='2'>
      <update id='org.eclipse.equinox.launcher' range='[0.0.0,1.6.600.v20231106-1826)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Equinox Launcher'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='launcher'/>
        <property name='maven-groupId' value='org.eclipse.equinox'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.launcher'/>
        <property name='maven-version' value='1.6.600-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher' version='1.6.600.v20231106-1826'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.launcher' version='1.6.600.v20231106-1826'/>
        <provided namespace='java.package' name='org.eclipse.core.launcher' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.launcher' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.launcher' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.launcher' version='1.6.600.v20231106-1826'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.eclipse.equinox.launcher
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.launcher' version='1.6.600.v20231106-1826'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.launcher;singleton:=true&#xA;Bundle-Version: 1.6.600.v20231106-1826
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.launcher.gtk.linux.x86_64' version='1.2.800.v20231003-1442'>
      <update id='org.eclipse.equinox.launcher.gtk.linux.x86_64' range='[0.0.0,1.2.800.v20231003-1442)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Equinox Launcher Linux X86_64 Fragment'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='launcher.gtk.linux.x86_64'/>
        <property name='maven-groupId' value='org.eclipse.equinox'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.launcher.gtk.linux.x86_64'/>
        <property name='maven-version' value='1.2.800-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.gtk.linux.x86_64' version='1.2.800.v20231003-1442'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.launcher.gtk.linux.x86_64' version='1.2.800.v20231003-1442'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.launcher.gtk.linux.x86_64' version='1.2.800.v20231003-1442'>
          <properties size='1'>
            <property name='type' value='osgi.fragment'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='osgi.fragment' name='org.eclipse.equinox.launcher' version='1.2.800.v20231003-1442'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.launcher' range='[1.5.0,1.7.0)'/>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
      </filter>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.launcher.gtk.linux.x86_64' version='1.2.800.v20231003-1442'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='zipped'>
            true
          </instruction>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.launcher.gtk.linux.x86_64;singleton:=true&#xA;Bundle-Version: 1.2.800.v20231003-1442&#xA;Fragment-Host: org.eclipse.equinox.launcher;bundle-version=&quot;[1.5.0,1.7.0)&quot;
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.preferences' version='3.10.400.v20231102-2218' generation='2'>
      <update id='org.eclipse.equinox.preferences' range='[0.0.0,3.10.400.v20231102-2218)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Eclipse Preferences Mechanism'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.equinox'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.preferences'/>
        <property name='maven-version' value='3.10.400-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.preferences' version='3.10.400.v20231102-2218'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.preferences' version='3.10.400.v20231102-2218'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.preferences' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.preferences.exchange' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime.preferences' version='3.5.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.preferences' version='3.10.400.v20231102-2218'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='12'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.18.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='[3.2.0,4.0.0)' optional='true' greedy='false'/>
        <required namespace='osgi.bundle' name='org.osgi.service.prefs' range='[1.1.0,1.2.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.log' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.environment' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'>
          <description>
            org.eclipse.equinox.preferences
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.preferences' version='3.10.400.v20231102-2218'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.preferences; singleton:=true&#xA;Bundle-Version: 3.10.400.v20231102-2218
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.registry' version='3.11.400.v20231102-2218' generation='2'>
      <update id='org.eclipse.equinox.registry' range='[0.0.0,3.11.400.v20231102-2218)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Extension Registry Support'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.equinox'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.registry'/>
        <property name='maven-version' value='3.11.400-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='12'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.registry' version='3.11.400.v20231102-2218'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.registry' version='3.11.400.v20231102-2218'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.adapter' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.registry' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.registry.osgi' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.registry.spi' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime' version='3.7.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime.dynamichelpers' version='3.4.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime.spi' version='3.4.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.registry' version='3.11.400.v20231102-2218'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='17'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.15.100,4.0.0)'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.jobs' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.console' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.environment' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.localization' range='1.1.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.resolver' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.storagemanager' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax.helpers' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'>
          <description>
            org.eclipse.equinox.registry
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.registry' version='3.11.400.v20231102-2218'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.registry;singleton:=true&#xA;Bundle-Version: 3.11.400.v20231102-2218
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.simpleconfigurator' version='1.5.0.v20230919-1457' generation='2'>
      <update id='org.eclipse.equinox.simpleconfigurator' range='[0.0.0,1.5.0.v20230919-1457)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.bundleName' value='Simple Configurator'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.equinox.p2'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.simpleconfigurator'/>
        <property name='maven-version' value='1.5.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='9'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.simpleconfigurator' version='1.5.0.v20230919-1457'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.simpleconfigurator' version='1.5.0.v20230919-1457'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.provisional.configurator' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.simpleconfigurator' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.simpleconfigurator.console' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.simpleconfigurator.utils' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.simpleconfigurator' version='1.5.0.v20230919-1457'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='11'>
        <required namespace='java.package' name='org.eclipse.osgi.framework.console' range='1.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='1.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.framework.namespace' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.framework.startlevel' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.framework.wiring' range='1.2.0'/>
        <required namespace='java.package' name='org.osgi.resource' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='1.2.0'/>
        <required namespace='java.package' name='org.osgi.service.startlevel' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='1.3.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.equinox.simpleconfigurator
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.simpleconfigurator' version='1.5.0.v20230919-1457'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.simpleconfigurator;singleton:=true&#xA;Bundle-Version: 1.5.0.v20230919-1457
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.fx.osgi' version='3.9.0.202210162353' singleton='false' generation='2'>
      <update id='org.eclipse.fx.osgi' range='[0.0.0,3.9.0.202210162353)' severity='0'/>
      <properties size='4'>
        <property name='df_LT.Bundle-Name' value='OSGi integration for JavaFX'/>
        <property name='df_LT.Bundle-Vendor' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%Bundle-Name'/>
        <property name='org.eclipse.equinox.p2.provider' value='%Bundle-Vendor'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.fx.osgi' version='3.9.0.202210162353'/>
        <provided namespace='osgi.bundle' name='org.eclipse.fx.osgi' version='3.9.0.202210162353'/>
        <provided namespace='osgi.identity' name='org.eclipse.fx.osgi' version='3.9.0.202210162353'>
          <properties size='1'>
            <property name='type' value='osgi.fragment'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='osgi.fragment' name='org.eclipse.osgi' version='3.9.0.202210162353'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='osgi.bundle' name='org.eclipse.osgi' range='3.10.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'>
          <description>
            org.eclipse.fx.osgi
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.fx.osgi.source' range='[3.9.0.202210162353,3.9.0.202210162353]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.fx.osgi' version='3.9.0.202210162353'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.fx.osgi&#xA;Bundle-Version: 3.9.0.202210162353&#xA;Fragment-Host: org.eclipse.osgi;bundle-version=&quot;3.10.0&quot;
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.osgi' version='3.18.600.v20231110-1900' generation='2'>
      <update id='org.eclipse.osgi' range='[0.0.0,3.18.600.v20231110-1900)' severity='0'/>
      <properties size='11'>
        <property name='df_LT.eclipse.org' value='Eclipse.org - Equinox'/>
        <property name='df_LT.systemBundle' value='OSGi System Bundle'/>
        <property name='org.eclipse.equinox.p2.name' value='%systemBundle'/>
        <property name='org.eclipse.equinox.p2.description' value='%systemBundle'/>
        <property name='org.eclipse.equinox.p2.provider' value='%eclipse.org'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='http://www.eclipse.org'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='systembundle'/>
        <property name='maven-groupId' value='org.eclipse.osgi'/>
        <property name='maven-artifactId' value='org.eclipse.osgi'/>
        <property name='maven-version' value='3.18.600-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='97'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi' version='3.18.600.v20231110-1900'/>
        <provided namespace='osgi.bundle' name='org.eclipse.osgi' version='3.18.600.v20231110-1900'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime.adaptor' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime.internal.adaptor' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.log' version='1.1.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.container' version='1.6.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.container.builders' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.container.namespaces' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.framework.console' version='1.1.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.framework.eventmgr' version='1.2.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.framework.internal.reliablefile' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.framework.log' version='1.1.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.framework.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.debug' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.framework' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.hookregistry' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.loader' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.loader.buddy' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.loader.classpath' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.loader.sources' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.location' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.messages' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.provisional.service.security' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.provisional.verifier' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.service.security' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.serviceregistry' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.signedcontent' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.url' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.launch' version='1.1.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.report.resolution' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.datalocation' version='1.4.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.debug' version='1.2.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.environment' version='1.4.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.localization' version='1.1.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.pluginconversion' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.resolver' version='1.6.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.runnable' version='1.1.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.security' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.urlconversion' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.signedcontent' version='1.1.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.storage' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.storage.bundlefile' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.storage.url.reference' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.storagemanager' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.util' version='1.1.0'/>
        <provided namespace='java.package' name='org.osgi.dto' version='1.1.1'/>
        <provided namespace='java.package' name='org.osgi.framework' version='1.10.0'/>
        <provided namespace='java.package' name='org.osgi.framework.connect' version='1.0.0'/>
        <provided namespace='java.package' name='org.osgi.framework.dto' version='1.8.0'/>
        <provided namespace='java.package' name='org.osgi.framework.hooks.bundle' version='1.1.0'/>
        <provided namespace='java.package' name='org.osgi.framework.hooks.resolver' version='1.0.0'/>
        <provided namespace='java.package' name='org.osgi.framework.hooks.service' version='1.1.0'/>
        <provided namespace='java.package' name='org.osgi.framework.hooks.weaving' version='1.1.0'/>
        <provided namespace='java.package' name='org.osgi.framework.launch' version='1.2.0'/>
        <provided namespace='java.package' name='org.osgi.framework.namespace' version='1.2.0'/>
        <provided namespace='java.package' name='org.osgi.framework.startlevel' version='1.0.0'/>
        <provided namespace='java.package' name='org.osgi.framework.startlevel.dto' version='1.0.0'/>
        <provided namespace='java.package' name='org.osgi.framework.wiring' version='1.2.0'/>
        <provided namespace='java.package' name='org.osgi.framework.wiring.dto' version='1.3.0'/>
        <provided namespace='java.package' name='org.osgi.resource' version='1.0.1'/>
        <provided namespace='java.package' name='org.osgi.resource.dto' version='1.0.1'/>
        <provided namespace='java.package' name='org.osgi.service.condition' version='1.0.0'/>
        <provided namespace='java.package' name='org.osgi.service.condpermadmin' version='1.1.2'/>
        <provided namespace='java.package' name='org.osgi.service.log' version='1.5.0'/>
        <provided namespace='java.package' name='org.osgi.service.log.admin' version='1.0.0'/>
        <provided namespace='java.package' name='org.osgi.service.packageadmin' version='1.2.1'/>
        <provided namespace='java.package' name='org.osgi.service.permissionadmin' version='1.2.1'/>
        <provided namespace='java.package' name='org.osgi.service.resolver' version='1.1.1'/>
        <provided namespace='java.package' name='org.osgi.service.startlevel' version='1.1.1'/>
        <provided namespace='java.package' name='org.osgi.service.url' version='1.0.1'/>
        <provided namespace='java.package' name='org.osgi.util.tracker' version='1.5.4'/>
        <provided namespace='osgi.identity' name='org.eclipse.osgi' version='3.18.600.v20231110-1900'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.18.600.v20231110-1900-1' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.osgi.service.log.LogReaderService,org.eclipse.equinox.log.ExtendedLogReaderService' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.18.600.v20231110-1900-2' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.osgi.service.log.LoggerFactory,org.osgi.service.log.LogService,org.eclipse.equinox.log.ExtendedLogService' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.18.600.v20231110-1900-3' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.osgi.service.log.admin.LoggerAdmin' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.18.600.v20231110-1900-4' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.eclipse.osgi.framework.log.FrameworkLog' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.18.600.v20231110-1900-5' version='0.0.0'>
          <properties size='2'>
            <property name='objectClass' value='org.eclipse.osgi.service.datalocation.Location' type='List'/>
            <property name='type' value='osgi.user.area'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.18.600.v20231110-1900-6' version='0.0.0'>
          <properties size='2'>
            <property name='objectClass' value='org.eclipse.osgi.service.datalocation.Location' type='List'/>
            <property name='type' value='osgi.instance.area'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.18.600.v20231110-1900-7' version='0.0.0'>
          <properties size='2'>
            <property name='objectClass' value='org.eclipse.osgi.service.datalocation.Location' type='List'/>
            <property name='type' value='osgi.configuration.area'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.18.600.v20231110-1900-8' version='0.0.0'>
          <properties size='2'>
            <property name='objectClass' value='org.eclipse.osgi.service.datalocation.Location' type='List'/>
            <property name='type' value='osgi.install.area'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.18.600.v20231110-1900-9' version='0.0.0'>
          <properties size='2'>
            <property name='objectClass' value='org.eclipse.osgi.service.datalocation.Location' type='List'/>
            <property name='type' value='eclipse.home.location'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.18.600.v20231110-1900-10' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.eclipse.osgi.service.environment.EnvironmentInfo' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.18.600.v20231110-1900-11' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.osgi.service.packageadmin.PackageAdmin' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.18.600.v20231110-1900-12' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.osgi.service.startlevel.StartLevel' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.18.600.v20231110-1900-13' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.osgi.service.permissionadmin.PermissionAdmin' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.18.600.v20231110-1900-14' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.osgi.service.condpermadmin.ConditionalPermissionAdmin' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.18.600.v20231110-1900-15' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.osgi.service.resolver.Resolver' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.18.600.v20231110-1900-16' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.eclipse.osgi.service.debug.DebugOptions' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.18.600.v20231110-1900-17' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.eclipse.osgi.service.urlconversion.URLConverter' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.18.600.v20231110-1900-18' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.eclipse.osgi.service.localization.BundleLocalization' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.18.600.v20231110-1900-19' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.eclipse.osgi.service.security.TrustEngine' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.18.600.v20231110-1900-20' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.eclipse.osgi.signedcontent.SignedContentFactory' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.18.600.v20231110-1900-21' version='0.0.0'>
          <properties size='2'>
            <property name='objectClass' value='org.osgi.service.condition.Condition' type='List'/>
            <property name='osgi.condition.id' value='true'/>
          </properties>
        </provided>
        <provided namespace='osgi.serviceloader' name='org.osgi.framework.connect.ConnectFrameworkFactory' version='0.0.0'/>
        <provided namespace='osgi.serviceloader' name='org.osgi.framework.launch.FrameworkFactory' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <requiredProperties namespace='osgi.ee' match='(&amp;(version=1.8)(|(osgi.ee=JavaSE)(osgi.ee=JavaSE/compact1)))'>
          <description>
            org.eclipse.osgi
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.osgi' version='3.18.600.v20231110-1900'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.osgi; singleton:=true&#xA;Bundle-Version: 3.18.600.v20231110-1900
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.osgi.compatibility.state' version='1.2.900.v20231106-0859' singleton='false' generation='2'>
      <update id='org.eclipse.osgi.compatibility.state' range='[0.0.0,1.2.900.v20231106-0859)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.Bundle-Name' value='Equinox State and Resolver Compatibility Fragment'/>
        <property name='df_LT.Bundle-Vendor' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%Bundle-Name'/>
        <property name='org.eclipse.equinox.p2.provider' value='%Bundle-Vendor'/>
        <property name='maven-groupId' value='org.eclipse.equinox'/>
        <property name='maven-artifactId' value='org.eclipse.osgi.compatibility.state'/>
        <property name='maven-version' value='1.2.900-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.compatibility.state' version='1.2.900.v20231106-0859'/>
        <provided namespace='osgi.bundle' name='org.eclipse.osgi.compatibility.state' version='1.2.900.v20231106-0859'/>
        <provided namespace='osgi.identity' name='org.eclipse.osgi.compatibility.state' version='1.2.900.v20231106-0859'>
          <properties size='1'>
            <property name='type' value='osgi.fragment'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='osgi.fragment' name='org.eclipse.osgi' version='1.2.900.v20231106-0859'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.osgi' range='3.12.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.eclipse.osgi.compatibility.state
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.osgi.compatibility.state' version='1.2.900.v20231106-0859'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.osgi.compatibility.state&#xA;Bundle-Version: 1.2.900.v20231106-0859&#xA;Fragment-Host: org.eclipse.osgi;bundle-version=&quot;3.12.0&quot;
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.osgi.services' version='3.11.200.v20231106-0901' singleton='false' generation='2'>
      <update id='org.eclipse.osgi.services' range='[0.0.0,3.11.200.v20231106-0901)' severity='0'/>
      <properties size='13'>
        <property name='df_LT.osgiServicesDes' value='OSGi Service Platform Release 4.2.0 Service Interfaces and Classes'/>
        <property name='df_LT.osgiServices' value='OSGi Release 4.2.0 Services'/>
        <property name='df_LT.eclipse.org' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%osgiServices'/>
        <property name='org.eclipse.equinox.p2.description' value='%osgiServicesDes'/>
        <property name='org.eclipse.equinox.p2.provider' value='%eclipse.org'/>
        <property name='org.eclipse.equinox.p2.contact' value='www.eclipse.org'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='http://www.eclipse.org'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.equinox'/>
        <property name='maven-artifactId' value='org.eclipse.osgi.services'/>
        <property name='maven-version' value='3.11.200-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='12'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.services' version='3.11.200.v20231106-0901'/>
        <provided namespace='osgi.bundle' name='org.eclipse.osgi.services' version='3.11.200.v20231106-0901'/>
        <provided namespace='java.package' name='org.osgi.service.component.annotations' version='1.3.0'/>
        <provided namespace='java.package' name='org.osgi.service.http' version='1.2.1'/>
        <provided namespace='java.package' name='org.osgi.service.http.context' version='1.1.0'/>
        <provided namespace='java.package' name='org.osgi.service.http.runtime' version='1.1.0'/>
        <provided namespace='java.package' name='org.osgi.service.http.runtime.dto' version='1.1.0'/>
        <provided namespace='java.package' name='org.osgi.service.http.whiteboard' version='1.1.0'/>
        <provided namespace='java.package' name='org.osgi.service.log' version='1.5.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.osgi.services' version='3.11.200.v20231106-0901'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='21'>
        <required namespace='osgi.bundle' name='org.osgi.service.event' range='[1.4.0,1.5.0)'/>
        <required namespace='osgi.bundle' name='org.osgi.service.wireadmin' range='[1.0.0,1.1.0)'/>
        <required namespace='java.package' name='org.osgi.service.http.whiteboard' range='[1.1.0,1.2.0)'/>
        <required namespace='java.package' name='org.osgi.service.http.runtime' range='[1.1.0,1.2.0)'/>
        <required namespace='java.package' name='javax.servlet.http' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='osgi.bundle' name='org.osgi.service.provisioning' range='[1.2.0,1.3.0)'/>
        <required namespace='osgi.bundle' name='org.osgi.service.upnp' range='[1.2.0,1.3.0)'/>
        <required namespace='java.package' name='org.osgi.framework.dto' range='1.8.0'/>
        <required namespace='osgi.bundle' name='org.osgi.service.useradmin' range='[1.1.0,1.2.0)'/>
        <required namespace='java.package' name='org.osgi.dto' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.service.http' range='[1.2.0,1.3.0)'/>
        <required namespace='osgi.bundle' name='org.osgi.service.component' range='[1.5.0,1.6.0)'/>
        <required namespace='java.package' name='org.osgi.service.http.runtime.dto' range='[1.1.0,1.2.0)'/>
        <required namespace='java.package' name='org.osgi.service.log' range='[1.5.0,1.6.0)'/>
        <required namespace='java.package' name='org.osgi.service.http.context' range='[1.1.0,1.2.0)'/>
        <required namespace='osgi.bundle' name='org.osgi.service.device' range='[1.1.0,1.2.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.eclipse.osgi.services
          </description>
        </requiredProperties>
        <required namespace='java.package' name='javax.servlet' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.6.0'/>
        <required namespace='osgi.bundle' name='org.osgi.service.cm' range='[1.6.0,1.7.0)'/>
        <required namespace='osgi.bundle' name='org.osgi.service.metatype' range='[1.4.0,1.5.0)'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.osgi.services' version='3.11.200.v20231106-0901'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.osgi.services&#xA;Bundle-Version: 3.11.200.v20231106-0901
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.osgi.util' version='3.7.300.v20231104-1118' singleton='false' generation='2'>
      <update id='org.eclipse.osgi.util' range='[0.0.0,3.7.300.v20231104-1118)' severity='0'/>
      <properties size='13'>
        <property name='df_LT.osgiUtilDes' value='OSGi Service Platform Release 4.2.0 Utility Classes'/>
        <property name='df_LT.eclipse.org' value='Eclipse.org - Equinox'/>
        <property name='df_LT.osgiUtil' value='OSGi Release 4.2.0 Utility Classes'/>
        <property name='org.eclipse.equinox.p2.name' value='%osgiUtil'/>
        <property name='org.eclipse.equinox.p2.description' value='%osgiUtilDes'/>
        <property name='org.eclipse.equinox.p2.provider' value='%eclipse.org'/>
        <property name='org.eclipse.equinox.p2.contact' value='www.eclipse.org'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='http://www.eclipse.org'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.equinox'/>
        <property name='maven-artifactId' value='org.eclipse.osgi.util'/>
        <property name='maven-version' value='3.7.300-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.util' version='3.7.300.v20231104-1118'/>
        <provided namespace='osgi.bundle' name='org.eclipse.osgi.util' version='3.7.300.v20231104-1118'/>
        <provided namespace='osgi.identity' name='org.eclipse.osgi.util' version='3.7.300.v20231104-1118'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='6'>
        <required namespace='osgi.bundle' name='org.osgi.util.function' range='[1.2.0,2.0.0)'/>
        <required namespace='osgi.bundle' name='org.osgi.util.promise' range='[1.2.0,2.0.0)'/>
        <required namespace='osgi.bundle' name='org.osgi.util.measurement' range='[1.0.0,2.0.0)'/>
        <required namespace='osgi.bundle' name='org.osgi.util.position' range='[1.0.0,2.0.0)'/>
        <required namespace='osgi.bundle' name='org.osgi.util.xml' range='[1.0.0,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.eclipse.osgi.util
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.osgi.util' version='3.7.300.v20231104-1118'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.osgi.util&#xA;Bundle-Version: 3.7.300.v20231104-1118
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eventb.core' version='3.7.0.202406100806-9b87fe13d' generation='2'>
      <update id='org.eventb.core' range='[0.0.0,3.7.0.202406100806-9b87fe13d)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Event-B Core Plugin'/>
        <property name='df_LT.providerName' value='ETH Zurich'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eventb'/>
        <property name='maven-artifactId' value='org.eventb.core'/>
        <property name='maven-version' value='3.7.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='31'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eventb.core' version='3.7.0.202406100806-9b87fe13d'/>
        <provided namespace='osgi.bundle' name='org.eventb.core' version='3.7.0.202406100806-9b87fe13d'/>
        <provided namespace='java.package' name='org.eventb.core' version='0.0.0'/>
        <provided namespace='java.package' name='org.eventb.core.basis' version='0.0.0'/>
        <provided namespace='java.package' name='org.eventb.core.extension' version='0.0.0'/>
        <provided namespace='java.package' name='org.eventb.core.pm' version='0.0.0'/>
        <provided namespace='java.package' name='org.eventb.core.pog' version='0.0.0'/>
        <provided namespace='java.package' name='org.eventb.core.pog.state' version='0.0.0'/>
        <provided namespace='java.package' name='org.eventb.core.preferences' version='0.0.0'/>
        <provided namespace='java.package' name='org.eventb.core.preferences.autotactics' version='0.0.0'/>
        <provided namespace='java.package' name='org.eventb.core.sc' version='0.0.0'/>
        <provided namespace='java.package' name='org.eventb.core.sc.state' version='0.0.0'/>
        <provided namespace='java.package' name='org.eventb.core.tool' version='0.0.0'/>
        <provided namespace='java.package' name='org.eventb.internal.core' version='0.0.0'/>
        <provided namespace='java.package' name='org.eventb.internal.core.autocompletion' version='0.0.0'/>
        <provided namespace='java.package' name='org.eventb.internal.core.indexers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eventb.internal.core.pm' version='0.0.0'/>
        <provided namespace='java.package' name='org.eventb.internal.core.pog' version='0.0.0'/>
        <provided namespace='java.package' name='org.eventb.internal.core.pog.modules' version='0.0.0'/>
        <provided namespace='java.package' name='org.eventb.internal.core.pom' version='0.0.0'/>
        <provided namespace='java.package' name='org.eventb.internal.core.preferences' version='0.0.0'/>
        <provided namespace='java.package' name='org.eventb.internal.core.sc' version='0.0.0'/>
        <provided namespace='java.package' name='org.eventb.internal.core.sc.modules' version='0.0.0'/>
        <provided namespace='java.package' name='org.eventb.internal.core.sc.symbolTable' version='0.0.0'/>
        <provided namespace='java.package' name='org.eventb.internal.core.tool' version='0.0.0'/>
        <provided namespace='java.package' name='org.eventb.internal.core.tool.graph' version='0.0.0'/>
        <provided namespace='java.package' name='org.eventb.internal.core.tool.state' version='0.0.0'/>
        <provided namespace='java.package' name='org.eventb.internal.core.upgrade' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eventb.core' version='3.7.0.202406100806-9b87fe13d'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='7'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.rodinp.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eventb.core.ast' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eventb.core.seqprover' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.resources' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eventb.core
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eventb.core.source' range='[3.7.0.202406100806-9b87fe13d,3.7.0.202406100806-9b87fe13d]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eventb.core' version='3.7.0.202406100806-9b87fe13d'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eventb.core; singleton:=true&#xA;Bundle-Version: 3.7.0.202406100806-9b87fe13d
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eventb.core.ast' version='3.8.0.202406100806-9b87fe13d' generation='2'>
      <update id='org.eventb.core.ast' range='[0.0.0,3.8.0.202406100806-9b87fe13d)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Event-B Abstract Syntax Tree Plug-in'/>
        <property name='df_LT.providerName' value='ETH Zurich'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eventb'/>
        <property name='maven-artifactId' value='org.eventb.core.ast'/>
        <property name='maven-version' value='3.8.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='17'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eventb.core.ast' version='3.8.0.202406100806-9b87fe13d'/>
        <provided namespace='osgi.bundle' name='org.eventb.core.ast' version='3.8.0.202406100806-9b87fe13d'/>
        <provided namespace='java.package' name='org.eventb.core.ast' version='0.0.0'/>
        <provided namespace='java.package' name='org.eventb.core.ast.datatype' version='0.0.0'/>
        <provided namespace='java.package' name='org.eventb.core.ast.expanders' version='0.0.0'/>
        <provided namespace='java.package' name='org.eventb.core.ast.extension' version='0.0.0'/>
        <provided namespace='java.package' name='org.eventb.internal.core.ast' version='0.0.0'/>
        <provided namespace='java.package' name='org.eventb.internal.core.ast.datatype' version='0.0.0'/>
        <provided namespace='java.package' name='org.eventb.internal.core.ast.extension' version='0.0.0'/>
        <provided namespace='java.package' name='org.eventb.internal.core.ast.wd' version='0.0.0'/>
        <provided namespace='java.package' name='org.eventb.internal.core.lexer' version='0.0.0'/>
        <provided namespace='java.package' name='org.eventb.internal.core.parser' version='0.0.0'/>
        <provided namespace='java.package' name='org.eventb.internal.core.parser.operators' version='0.0.0'/>
        <provided namespace='java.package' name='org.eventb.internal.core.typecheck' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eventb.core.ast' version='3.8.0.202406100806-9b87fe13d'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eventb.core.ast
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eventb.core.ast.source' range='[3.8.0.202406100806-9b87fe13d,3.8.0.202406100806-9b87fe13d]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eventb.core.ast' version='3.8.0.202406100806-9b87fe13d'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eventb.core.ast;singleton:=true&#xA;Bundle-Version: 3.8.0.202406100806-9b87fe13d
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eventb.core.seqprover' version='3.7.0.202406100806-9b87fe13d' generation='2'>
      <update id='org.eventb.core.seqprover' range='[0.0.0,3.7.0.202406100806-9b87fe13d)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Event-B Sequent Prover Plug-in'/>
        <property name='df_LT.pluginProvider' value='ETH Zurich'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%pluginProvider'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eventb'/>
        <property name='maven-artifactId' value='org.eventb.core.seqprover'/>
        <property name='maven-version' value='3.7.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='24'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eventb.core.seqprover' version='3.7.0.202406100806-9b87fe13d'/>
        <provided namespace='osgi.bundle' name='org.eventb.core.seqprover' version='3.7.0.202406100806-9b87fe13d'/>
        <provided namespace='java.package' name='org.eventb.core.seqprover' version='0.0.0'/>
        <provided namespace='java.package' name='org.eventb.core.seqprover.autoTacticPreference' version='0.0.0'/>
        <provided namespace='java.package' name='org.eventb.core.seqprover.eventbExtensions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eventb.core.seqprover.proofBuilder' version='0.0.0'/>
        <provided namespace='java.package' name='org.eventb.core.seqprover.reasonerInputs' version='0.0.0'/>
        <provided namespace='java.package' name='org.eventb.core.seqprover.reasoners' version='0.0.0'/>
        <provided namespace='java.package' name='org.eventb.core.seqprover.tactics' version='0.0.0'/>
        <provided namespace='java.package' name='org.eventb.core.seqprover.transformer' version='0.0.0'/>
        <provided namespace='java.package' name='org.eventb.core.seqprover.xprover' version='0.0.0'/>
        <provided namespace='java.package' name='org.eventb.internal.core.seqprover' version='0.0.0'/>
        <provided namespace='java.package' name='org.eventb.internal.core.seqprover.eventbExtensions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eventb.internal.core.seqprover.eventbExtensions.genmp' version='0.0.0'/>
        <provided namespace='java.package' name='org.eventb.internal.core.seqprover.eventbExtensions.mbGoal' version='0.0.0'/>
        <provided namespace='java.package' name='org.eventb.internal.core.seqprover.eventbExtensions.rewriters' version='0.0.0'/>
        <provided namespace='java.package' name='org.eventb.internal.core.seqprover.eventbExtensions.utils' version='0.0.0'/>
        <provided namespace='java.package' name='org.eventb.internal.core.seqprover.proofBuilder' version='0.0.0'/>
        <provided namespace='java.package' name='org.eventb.internal.core.seqprover.proofSimplifier2' version='0.0.0'/>
        <provided namespace='java.package' name='org.eventb.internal.core.seqprover.reasonerInputs' version='0.0.0'/>
        <provided namespace='java.package' name='org.eventb.internal.core.seqprover.transformer' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eventb.core.seqprover' version='3.7.0.202406100806-9b87fe13d'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='5'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.filesystem' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eventb.core.ast' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eventb.core.seqprover
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eventb.core.seqprover.source' range='[3.7.0.202406100806-9b87fe13d,3.7.0.202406100806-9b87fe13d]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eventb.core.seqprover' version='3.7.0.202406100806-9b87fe13d'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eventb.core.seqprover; singleton:=true&#xA;Bundle-Version: 3.7.0.202406100806-9b87fe13d
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.osgi.service.cm' version='1.6.1.202109301733' singleton='false' generation='2'>
      <update id='org.osgi.service.cm' range='[0.0.0,1.6.1.202109301733)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='org.osgi:org.osgi.service.cm'/>
        <property name='org.eclipse.equinox.p2.description' value='OSGi Companion Code for org.osgi.service.cm Version 1.6.1'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse Foundation'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://docs.osgi.org/'/>
        <property name='maven-groupId' value='org.osgi'/>
        <property name='maven-artifactId' value='org.osgi.service.cm'/>
        <property name='maven-version' value='1.6.1'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.cm' version='1.6.1.202109301733'/>
        <provided namespace='osgi.bundle' name='org.osgi.service.cm' version='1.6.1.202109301733'/>
        <provided namespace='java.package' name='org.osgi.service.cm' version='1.6.1'/>
        <provided namespace='java.package' name='org.osgi.service.cm.annotations' version='1.6.1'/>
        <provided namespace='osgi.identity' name='org.osgi.service.cm' version='1.6.1.202109301733'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='java.package' name='org.osgi.framework' range='[1.8.0,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE/compact1)(version=1.8))'>
          <description>
            org.osgi.service.cm
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.osgi.service.cm' version='1.6.1.202109301733'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.osgi.service.cm&#xA;Bundle-Version: 1.6.1.202109301733
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.osgi.service.component' version='1.5.1.202212101352' singleton='false' generation='2'>
      <update id='org.osgi.service.component' range='[0.0.0,1.5.1.202212101352)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='org.osgi:org.osgi.service.component'/>
        <property name='org.eclipse.equinox.p2.description' value='OSGi Companion Code for org.osgi.service.component Version 1.5.1'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse Foundation'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://docs.osgi.org/'/>
        <property name='maven-groupId' value='org.osgi'/>
        <property name='maven-artifactId' value='org.osgi.service.component'/>
        <property name='maven-version' value='1.5.1'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.component' version='1.5.1.202212101352'/>
        <provided namespace='osgi.bundle' name='org.osgi.service.component' version='1.5.1.202212101352'/>
        <provided namespace='java.package' name='org.osgi.service.component' version='1.5.1'/>
        <provided namespace='java.package' name='org.osgi.service.component.propertytypes' version='1.5.0'/>
        <provided namespace='java.package' name='org.osgi.service.component.runtime' version='1.5.0'/>
        <provided namespace='java.package' name='org.osgi.service.component.runtime.dto' version='1.5.0'/>
        <provided namespace='osgi.identity' name='org.osgi.service.component' version='1.5.1.202212101352'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='6'>
        <required namespace='java.package' name='org.osgi.dto' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.8.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework.dto' range='[1.8.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.service.component.runtime.dto' range='[1.5.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.util.promise' range='[1.0.0,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE/compact1)(version=1.8))'>
          <description>
            org.osgi.service.component
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.osgi.service.component' version='1.5.1.202212101352'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.osgi.service.component&#xA;Bundle-Version: 1.5.1.202212101352
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.osgi.service.device' version='1.1.1.202109301733' singleton='false' generation='2'>
      <update id='org.osgi.service.device' range='[0.0.0,1.1.1.202109301733)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='org.osgi:org.osgi.service.device'/>
        <property name='org.eclipse.equinox.p2.description' value='OSGi Companion Code for org.osgi.service.device Version 1.1.1'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse Foundation'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://docs.osgi.org/'/>
        <property name='maven-groupId' value='org.osgi'/>
        <property name='maven-artifactId' value='org.osgi.service.device'/>
        <property name='maven-version' value='1.1.1'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.device' version='1.1.1.202109301733'/>
        <provided namespace='osgi.bundle' name='org.osgi.service.device' version='1.1.1.202109301733'/>
        <provided namespace='java.package' name='org.osgi.service.device' version='1.1.1'/>
        <provided namespace='osgi.identity' name='org.osgi.service.device' version='1.1.1.202109301733'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='java.package' name='org.osgi.framework' range='[1.8.0,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE/compact1)(version=1.8))'>
          <description>
            org.osgi.service.device
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.osgi.service.device' version='1.1.1.202109301733'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.osgi.service.device&#xA;Bundle-Version: 1.1.1.202109301733
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.osgi.service.event' version='1.4.1.202109301733' singleton='false' generation='2'>
      <update id='org.osgi.service.event' range='[0.0.0,1.4.1.202109301733)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='org.osgi:org.osgi.service.event'/>
        <property name='org.eclipse.equinox.p2.description' value='OSGi Companion Code for org.osgi.service.event Version 1.4.1'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse Foundation'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://docs.osgi.org/'/>
        <property name='maven-groupId' value='org.osgi'/>
        <property name='maven-artifactId' value='org.osgi.service.event'/>
        <property name='maven-version' value='1.4.1'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.event' version='1.4.1.202109301733'/>
        <provided namespace='osgi.bundle' name='org.osgi.service.event' version='1.4.1.202109301733'/>
        <provided namespace='java.package' name='org.osgi.service.event' version='1.4.1'/>
        <provided namespace='java.package' name='org.osgi.service.event.annotations' version='1.4.1'/>
        <provided namespace='java.package' name='org.osgi.service.event.propertytypes' version='1.4.0'/>
        <provided namespace='osgi.identity' name='org.osgi.service.event' version='1.4.1.202109301733'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='java.package' name='org.osgi.framework' range='[1.8.0,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE/compact1)(version=1.8))'>
          <description>
            org.osgi.service.event
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.osgi.service.event' version='1.4.1.202109301733'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.osgi.service.event&#xA;Bundle-Version: 1.4.1.202109301733
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.osgi.service.metatype' version='1.4.1.202109301733' singleton='false' generation='2'>
      <update id='org.osgi.service.metatype' range='[0.0.0,1.4.1.202109301733)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='org.osgi:org.osgi.service.metatype'/>
        <property name='org.eclipse.equinox.p2.description' value='OSGi Companion Code for org.osgi.service.metatype Version 1.4.1'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse Foundation'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://docs.osgi.org/'/>
        <property name='maven-groupId' value='org.osgi'/>
        <property name='maven-artifactId' value='org.osgi.service.metatype'/>
        <property name='maven-version' value='1.4.1'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.metatype' version='1.4.1.202109301733'/>
        <provided namespace='osgi.bundle' name='org.osgi.service.metatype' version='1.4.1.202109301733'/>
        <provided namespace='java.package' name='org.osgi.service.metatype' version='1.4.1'/>
        <provided namespace='osgi.identity' name='org.osgi.service.metatype' version='1.4.1.202109301733'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='java.package' name='org.osgi.framework' range='[1.8.0,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE/compact1)(version=1.8))'>
          <description>
            org.osgi.service.metatype
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.osgi.service.metatype' version='1.4.1.202109301733'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.osgi.service.metatype&#xA;Bundle-Version: 1.4.1.202109301733
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.osgi.service.prefs' version='1.1.2.202109301733' singleton='false' generation='2'>
      <update id='org.osgi.service.prefs' range='[0.0.0,1.1.2.202109301733)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='org.osgi:org.osgi.service.prefs'/>
        <property name='org.eclipse.equinox.p2.description' value='OSGi Companion Code for org.osgi.service.prefs Version 1.1.2'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse Foundation'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://docs.osgi.org/'/>
        <property name='maven-groupId' value='org.osgi'/>
        <property name='maven-artifactId' value='org.osgi.service.prefs'/>
        <property name='maven-version' value='1.1.2'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.prefs' version='1.1.2.202109301733'/>
        <provided namespace='osgi.bundle' name='org.osgi.service.prefs' version='1.1.2.202109301733'/>
        <provided namespace='java.package' name='org.osgi.service.prefs' version='1.1.2'/>
        <provided namespace='osgi.identity' name='org.osgi.service.prefs' version='1.1.2.202109301733'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE/compact1)(version=1.8))'>
          <description>
            org.osgi.service.prefs
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.osgi.service.prefs' version='1.1.2.202109301733'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.osgi.service.prefs&#xA;Bundle-Version: 1.1.2.202109301733
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.osgi.service.provisioning' version='1.2.0.201505202024' singleton='false' generation='2'>
      <update id='org.osgi.service.provisioning' range='[0.0.0,1.2.0.201505202024)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='org.osgi:org.osgi.service.provisioning'/>
        <property name='org.eclipse.equinox.p2.description' value='OSGi Companion Code for org.osgi.service.provisioning Version 1.2.0.'/>
        <property name='org.eclipse.equinox.p2.provider' value='OSGi Alliance http://www.osgi.org/'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='http://www.osgi.org/'/>
        <property name='maven-groupId' value='org.osgi'/>
        <property name='maven-artifactId' value='org.osgi.service.provisioning'/>
        <property name='maven-version' value='1.2.0'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.provisioning' version='1.2.0.201505202024'/>
        <provided namespace='osgi.bundle' name='org.osgi.service.provisioning' version='1.2.0.201505202024'/>
        <provided namespace='java.package' name='org.osgi.service.provisioning' version='1.2.0'/>
        <provided namespace='osgi.identity' name='org.osgi.service.provisioning' version='1.2.0.201505202024'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.2))'>
          <description>
            org.osgi.service.provisioning
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.osgi.service.provisioning' version='1.2.0.201505202024'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.osgi.service.provisioning&#xA;Bundle-Version: 1.2.0.201505202024
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.osgi.service.upnp' version='1.2.1.202109301733' singleton='false' generation='2'>
      <update id='org.osgi.service.upnp' range='[0.0.0,1.2.1.202109301733)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='org.osgi:org.osgi.service.upnp'/>
        <property name='org.eclipse.equinox.p2.description' value='OSGi Companion Code for org.osgi.service.upnp Version 1.2.1'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse Foundation'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://docs.osgi.org/'/>
        <property name='maven-groupId' value='org.osgi'/>
        <property name='maven-artifactId' value='org.osgi.service.upnp'/>
        <property name='maven-version' value='1.2.1'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.upnp' version='1.2.1.202109301733'/>
        <provided namespace='osgi.bundle' name='org.osgi.service.upnp' version='1.2.1.202109301733'/>
        <provided namespace='java.package' name='org.osgi.service.upnp' version='1.2.1'/>
        <provided namespace='osgi.identity' name='org.osgi.service.upnp' version='1.2.1.202109301733'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE/compact1)(version=1.8))'>
          <description>
            org.osgi.service.upnp
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.osgi.service.upnp' version='1.2.1.202109301733'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.osgi.service.upnp&#xA;Bundle-Version: 1.2.1.202109301733
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.osgi.service.useradmin' version='1.1.1.202109301733' singleton='false' generation='2'>
      <update id='org.osgi.service.useradmin' range='[0.0.0,1.1.1.202109301733)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='org.osgi:org.osgi.service.useradmin'/>
        <property name='org.eclipse.equinox.p2.description' value='OSGi Companion Code for org.osgi.service.useradmin Version 1.1.1'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse Foundation'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://docs.osgi.org/'/>
        <property name='maven-groupId' value='org.osgi'/>
        <property name='maven-artifactId' value='org.osgi.service.useradmin'/>
        <property name='maven-version' value='1.1.1'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.useradmin' version='1.1.1.202109301733'/>
        <provided namespace='osgi.bundle' name='org.osgi.service.useradmin' version='1.1.1.202109301733'/>
        <provided namespace='java.package' name='org.osgi.service.useradmin' version='1.1.1'/>
        <provided namespace='osgi.identity' name='org.osgi.service.useradmin' version='1.1.1.202109301733'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='java.package' name='org.osgi.framework' range='[1.8.0,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE/compact1)(version=1.8))'>
          <description>
            org.osgi.service.useradmin
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.osgi.service.useradmin' version='1.1.1.202109301733'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.osgi.service.useradmin&#xA;Bundle-Version: 1.1.1.202109301733
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.osgi.service.wireadmin' version='1.0.2.202109301733' singleton='false' generation='2'>
      <update id='org.osgi.service.wireadmin' range='[0.0.0,1.0.2.202109301733)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='org.osgi:org.osgi.service.wireadmin'/>
        <property name='org.eclipse.equinox.p2.description' value='OSGi Companion Code for org.osgi.service.wireadmin Version 1.0.2'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse Foundation'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://docs.osgi.org/'/>
        <property name='maven-groupId' value='org.osgi'/>
        <property name='maven-artifactId' value='org.osgi.service.wireadmin'/>
        <property name='maven-version' value='1.0.2'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.wireadmin' version='1.0.2.202109301733'/>
        <provided namespace='osgi.bundle' name='org.osgi.service.wireadmin' version='1.0.2.202109301733'/>
        <provided namespace='java.package' name='org.osgi.service.wireadmin' version='1.0.2'/>
        <provided namespace='osgi.identity' name='org.osgi.service.wireadmin' version='1.0.2.202109301733'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='java.package' name='org.osgi.framework' range='[1.8.0,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE/compact1)(version=1.8))'>
          <description>
            org.osgi.service.wireadmin
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.osgi.service.wireadmin' version='1.0.2.202109301733'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.osgi.service.wireadmin&#xA;Bundle-Version: 1.0.2.202109301733
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.osgi.util.function' version='1.2.0.202109301733' singleton='false' generation='2'>
      <update id='org.osgi.util.function' range='[0.0.0,1.2.0.202109301733)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='org.osgi:org.osgi.util.function'/>
        <property name='org.eclipse.equinox.p2.description' value='OSGi Companion Code for org.osgi.util.function Version 1.2.0'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse Foundation'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://docs.osgi.org/'/>
        <property name='maven-groupId' value='org.osgi'/>
        <property name='maven-artifactId' value='org.osgi.util.function'/>
        <property name='maven-version' value='1.2.0'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.osgi.util.function' version='1.2.0.202109301733'/>
        <provided namespace='osgi.bundle' name='org.osgi.util.function' version='1.2.0.202109301733'/>
        <provided namespace='java.package' name='org.osgi.util.function' version='1.2.0'/>
        <provided namespace='osgi.identity' name='org.osgi.util.function' version='1.2.0.202109301733'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE/compact1)(version=1.8))'>
          <description>
            org.osgi.util.function
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.osgi.util.function' version='1.2.0.202109301733'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.osgi.util.function&#xA;Bundle-Version: 1.2.0.202109301733
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.osgi.util.measurement' version='1.0.2.201802012109' singleton='false' generation='2'>
      <update id='org.osgi.util.measurement' range='[0.0.0,1.0.2.201802012109)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='org.osgi:org.osgi.util.measurement'/>
        <property name='org.eclipse.equinox.p2.description' value='OSGi Companion Code for org.osgi.util.measurement Version 1.0.2'/>
        <property name='org.eclipse.equinox.p2.provider' value='OSGi Alliance https://www.osgi.org/'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://www.osgi.org/'/>
        <property name='maven-groupId' value='org.osgi'/>
        <property name='maven-artifactId' value='org.osgi.util.measurement'/>
        <property name='maven-version' value='1.0.2'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.osgi.util.measurement' version='1.0.2.201802012109'/>
        <provided namespace='osgi.bundle' name='org.osgi.util.measurement' version='1.0.2.201802012109'/>
        <provided namespace='java.package' name='org.osgi.util.measurement' version='1.0.2'/>
        <provided namespace='osgi.identity' name='org.osgi.util.measurement' version='1.0.2.201802012109'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.7))'>
          <description>
            org.osgi.util.measurement
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.osgi.util.measurement' version='1.0.2.201802012109'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.osgi.util.measurement&#xA;Bundle-Version: 1.0.2.201802012109
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.osgi.util.position' version='1.0.1.201505202026' singleton='false' generation='2'>
      <update id='org.osgi.util.position' range='[0.0.0,1.0.1.201505202026)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='org.osgi:org.osgi.util.position'/>
        <property name='org.eclipse.equinox.p2.description' value='OSGi Companion Code for org.osgi.util.position Version 1.0.1.'/>
        <property name='org.eclipse.equinox.p2.provider' value='OSGi Alliance http://www.osgi.org/'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='http://www.osgi.org/'/>
        <property name='maven-groupId' value='org.osgi'/>
        <property name='maven-artifactId' value='org.osgi.util.position'/>
        <property name='maven-version' value='1.0.1'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.osgi.util.position' version='1.0.1.201505202026'/>
        <provided namespace='osgi.bundle' name='org.osgi.util.position' version='1.0.1.201505202026'/>
        <provided namespace='java.package' name='org.osgi.util.position' version='1.0.1'/>
        <provided namespace='osgi.identity' name='org.osgi.util.position' version='1.0.1.201505202026'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='java.package' name='org.osgi.util.measurement' range='[1.0.0,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.2))'>
          <description>
            org.osgi.util.position
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.osgi.util.position' version='1.0.1.201505202026'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.osgi.util.position&#xA;Bundle-Version: 1.0.1.201505202026
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.osgi.util.promise' version='1.3.0.202212101352' singleton='false' generation='2'>
      <update id='org.osgi.util.promise' range='[0.0.0,1.3.0.202212101352)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='org.osgi:org.osgi.util.promise'/>
        <property name='org.eclipse.equinox.p2.description' value='OSGi Companion Code for org.osgi.util.promise Version 1.3.0'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse Foundation'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://docs.osgi.org/'/>
        <property name='maven-groupId' value='org.osgi'/>
        <property name='maven-artifactId' value='org.osgi.util.promise'/>
        <property name='maven-version' value='1.3.0'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.osgi.util.promise' version='1.3.0.202212101352'/>
        <provided namespace='osgi.bundle' name='org.osgi.util.promise' version='1.3.0.202212101352'/>
        <provided namespace='java.package' name='org.osgi.util.promise' version='1.3.0'/>
        <provided namespace='osgi.identity' name='org.osgi.util.promise' version='1.3.0.202212101352'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='java.package' name='org.osgi.util.function' range='[1.1.0,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE/compact1)(version=1.8))'>
          <description>
            org.osgi.util.promise
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.osgi.util.promise' version='1.3.0.202212101352'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.osgi.util.promise&#xA;Bundle-Version: 1.3.0.202212101352
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.osgi.util.xml' version='1.0.2.202109301733' singleton='false' generation='2'>
      <update id='org.osgi.util.xml' range='[0.0.0,1.0.2.202109301733)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='org.osgi:org.osgi.util.xml'/>
        <property name='org.eclipse.equinox.p2.description' value='OSGi Companion Code for org.osgi.util.xml Version 1.0.2'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse Foundation'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://docs.osgi.org/'/>
        <property name='maven-groupId' value='org.osgi'/>
        <property name='maven-artifactId' value='org.osgi.util.xml'/>
        <property name='maven-version' value='1.0.2'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.osgi.util.xml' version='1.0.2.202109301733'/>
        <provided namespace='osgi.bundle' name='org.osgi.util.xml' version='1.0.2.202109301733'/>
        <provided namespace='java.package' name='org.osgi.util.xml' version='1.0.2'/>
        <provided namespace='osgi.identity' name='org.osgi.util.xml' version='1.0.2.202109301733'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.8.0,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE/compact1)(version=1.8))'>
          <description>
            org.osgi.util.xml
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.osgi.util.xml' version='1.0.2.202109301733'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.osgi.util.xml&#xA;Bundle-Version: 1.0.2.202109301733
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.rodinp.core' version='1.10.0.202406100806-9b87fe13d' generation='2'>
      <update id='org.rodinp.core' range='[0.0.0,1.10.0.202406100806-9b87fe13d)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Rodin Core'/>
        <property name='df_LT.providerName' value='ETH Zurich'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eventb'/>
        <property name='maven-artifactId' value='org.rodinp.core'/>
        <property name='maven-version' value='1.10.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='24'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.rodinp.core' version='1.10.0.202406100806-9b87fe13d'/>
        <provided namespace='osgi.bundle' name='org.rodinp.core' version='1.10.0.202406100806-9b87fe13d'/>
        <provided namespace='java.package' name='org.rodinp.core' version='0.0.0'/>
        <provided namespace='java.package' name='org.rodinp.core.basis' version='0.0.0'/>
        <provided namespace='java.package' name='org.rodinp.core.builder' version='0.0.0'/>
        <provided namespace='java.package' name='org.rodinp.core.indexer' version='0.0.0'/>
        <provided namespace='java.package' name='org.rodinp.core.location' version='0.0.0'/>
        <provided namespace='java.package' name='org.rodinp.core.version' version='0.0.0'/>
        <provided namespace='java.package' name='org.rodinp.internal.core' version='0.0.0'/>
        <provided namespace='java.package' name='org.rodinp.internal.core.builder' version='0.0.0'/>
        <provided namespace='java.package' name='org.rodinp.internal.core.debug' version='0.0.0'/>
        <provided namespace='java.package' name='org.rodinp.internal.core.indexer' version='0.0.0'/>
        <provided namespace='java.package' name='org.rodinp.internal.core.indexer.persistence' version='0.0.0'/>
        <provided namespace='java.package' name='org.rodinp.internal.core.indexer.persistence.xml' version='0.0.0'/>
        <provided namespace='java.package' name='org.rodinp.internal.core.indexer.sort' version='0.0.0'/>
        <provided namespace='java.package' name='org.rodinp.internal.core.indexer.tables' version='0.0.0'/>
        <provided namespace='java.package' name='org.rodinp.internal.core.location' version='0.0.0'/>
        <provided namespace='java.package' name='org.rodinp.internal.core.relations' version='0.0.0'/>
        <provided namespace='java.package' name='org.rodinp.internal.core.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.rodinp.internal.core.util.sort' version='0.0.0'/>
        <provided namespace='java.package' name='org.rodinp.internal.core.version' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.rodinp.core' version='1.10.0.202406100806-9b87fe13d'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='4'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.resources' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.rodinp.core
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.rodinp.core.source' range='[1.10.0.202406100806-9b87fe13d,1.10.0.202406100806-9b87fe13d]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.rodinp.core' version='1.10.0.202406100806-9b87fe13d'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.rodinp.core; singleton:=true&#xA;Bundle-Version: 1.10.0.202406100806-9b87fe13d
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='tooling.org.eclipse.update.feature.default' version='1.0.0' singleton='false'>
      <hostRequirements size='1'>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='feature' range='0.0.0' optional='true' multiple='true' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='tooling.org.eclipse.update.feature.default' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='tooling' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='feature' range='0.0.0' optional='true' multiple='true' greedy='false'/>
      </requires>
      <filter>
        (org.eclipse.update.install.features=true)
      </filter>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='uninstall'>
            uninstallFeature(feature:${artifact},featureId:default,featureVersion:default)
          </instruction>
          <instruction key='install'>
            installFeature(feature:${artifact},featureId:default,featureVersion:default)
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='tooling.osgi.bundle.default' version='1.0.0' singleton='false'>
      <hostRequirements size='1'>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='0.0.0' multiple='true' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='tooling.osgi.bundle.default' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='tooling' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='0.0.0' multiple='true' greedy='false'/>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='4'>
          <instruction key='uninstall'>
            uninstallBundle(bundle:${artifact})
          </instruction>
          <instruction key='install'>
            installBundle(bundle:${artifact})
          </instruction>
          <instruction key='configure'>
            setStartLevel(startLevel:4);
          </instruction>
          <instruction key='unconfigure'>

          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='tooling.source.default' version='1.0.0' singleton='false'>
      <hostRequirements size='1'>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='source' range='0.0.0' optional='true' multiple='true' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='tooling.source.default' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='tooling' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='source' range='0.0.0' optional='true' multiple='true' greedy='false'/>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='uninstall'>
            removeSourceBundle(bundle:${artifact})
          </instruction>
          <instruction key='install'>
            addSourceBundle(bundle:${artifact})
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolingeventbfileconverter.product.config.gtk.linux.x86_64' version='1.0.0.202509081441' singleton='false'>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolingeventbfileconverter.product.config.gtk.linux.x86_64' version='1.0.0.202509081441'/>
        <provided namespace='toolingeventbfileconverter.product' name='eventbfileconverter.product.config' version='1.0.0.202509081441'/>
      </provides>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
      </filter>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='configure'>
            setProgramProperty(propName:eclipse.product,propValue:EventBFileConverter.product);setProgramProperty(propName:eclipse.application,propValue:EventBFileConverter.app);
          </instruction>
          <instruction key='unconfigure'>
            setProgramProperty(propName:eclipse.product,propValue:);setProgramProperty(propName:eclipse.application,propValue:);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolingeventbfileconverter.product.configuration' version='1.0.0.202509081441'>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolingeventbfileconverter.product.configuration' version='1.0.0.202509081441'/>
      </provides>
      <requires size='9'>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingeventbfileconverter.product.ini.gtk.linux.x86_64' range='[1.0.0.202509081441,1.0.0.202509081441]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.x86_64org.apache.felix.scr' range='[1.0.0.202509081441,1.0.0.202509081441]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.x86_64org.eclipse.core.resources' range='[1.0.0.202509081441,1.0.0.202509081441]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.x86_64org.eclipse.equinox.simpleconfigurator' range='[1.0.0.202509081441,1.0.0.202509081441]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingeventbfileconverter.product.config.gtk.linux.x86_64' range='[1.0.0.202509081441,1.0.0.202509081441]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.x86_64org.eclipse.core.contenttype' range='[1.0.0.202509081441,1.0.0.202509081441]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.x86_64org.eclipse.equinox.event' range='[1.0.0.202509081441,1.0.0.202509081441]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.x86_64org.eclipse.equinox.common' range='[1.0.0.202509081441,1.0.0.202509081441]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.x86_64org.eclipse.core.runtime' range='[1.0.0.202509081441,1.0.0.202509081441]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
    </unit>
    <unit id='toolingeventbfileconverter.product.ini.gtk.linux.x86_64' version='1.0.0.202509081441' singleton='false'>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolingeventbfileconverter.product.ini.gtk.linux.x86_64' version='1.0.0.202509081441'/>
        <provided namespace='toolingeventbfileconverter.product' name='eventbfileconverter.product.ini' version='1.0.0.202509081441'/>
      </provides>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
      </filter>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='configure'>
            addProgramArg(programArg:-consoleLog);addProgramArg(programArg:-clean);
          </instruction>
          <instruction key='unconfigure'>
            removeProgramArg(programArg:-consoleLog);removeProgramArg(programArg:-clean);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolingeventbfileconverter.product_root.gtk.linux.x86_64' version='1.0.0.202509081441' singleton='false'>
      <properties size='1'>
        <property name='org.eclipse.pde.build.default' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolingeventbfileconverter.product_root.gtk.linux.x86_64' version='1.0.0.202509081441'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='tooling' version='1.0.0'/>
      </provides>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
      </filter>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='configure'>
            setLauncherName(name:eclipse)
          </instruction>
          <instruction key='unconfigure'>
            setLauncherName()
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolinggtk.linux.x86_64org.apache.felix.scr' version='1.0.0.202509081441' singleton='false'>
      <hostRequirements size='2'>
        <required namespace='osgi.bundle' name='org.apache.felix.scr' range='2.2.6'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.x86_64org.apache.felix.scr' version='1.0.0.202509081441'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='toolinggtk.linux.x86_64' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.apache.felix.scr' range='2.2.6'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
      </filter>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='4'>
          <instruction key='uninstall'>
            uninstallBundle(bundle:${artifact})
          </instruction>
          <instruction key='install'>
            installBundle(bundle:${artifact})
          </instruction>
          <instruction key='configure'>
            setStartLevel(startLevel:2);markStarted(started: true);
          </instruction>
          <instruction key='unconfigure'>
            setStartLevel(startLevel:-1);markStarted(started: false);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolinggtk.linux.x86_64org.eclipse.core.contenttype' version='1.0.0.202509081441' singleton='false'>
      <hostRequirements size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.core.contenttype' range='3.9.200.v20230914-0751'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.x86_64org.eclipse.core.contenttype' version='1.0.0.202509081441'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='toolinggtk.linux.x86_64' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.core.contenttype' range='3.9.200.v20230914-0751'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
      </filter>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='4'>
          <instruction key='uninstall'>
            uninstallBundle(bundle:${artifact})
          </instruction>
          <instruction key='install'>
            installBundle(bundle:${artifact})
          </instruction>
          <instruction key='configure'>
            setStartLevel(startLevel:2);
          </instruction>
          <instruction key='unconfigure'>
            setStartLevel(startLevel:-1);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolinggtk.linux.x86_64org.eclipse.core.resources' version='1.0.0.202509081441' singleton='false'>
      <hostRequirements size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.core.resources' range='3.20.0.v20231102-0934'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.x86_64org.eclipse.core.resources' version='1.0.0.202509081441'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='toolinggtk.linux.x86_64' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.core.resources' range='3.20.0.v20231102-0934'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
      </filter>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='4'>
          <instruction key='uninstall'>
            uninstallBundle(bundle:${artifact})
          </instruction>
          <instruction key='install'>
            installBundle(bundle:${artifact})
          </instruction>
          <instruction key='configure'>
            setStartLevel(startLevel:4);
          </instruction>
          <instruction key='unconfigure'>
            setStartLevel(startLevel:-1);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolinggtk.linux.x86_64org.eclipse.core.runtime' version='1.0.0.202509081441' singleton='false'>
      <hostRequirements size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='3.30.0.v20231102-0719'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.x86_64org.eclipse.core.runtime' version='1.0.0.202509081441'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='toolinggtk.linux.x86_64' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='3.30.0.v20231102-0719'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
      </filter>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='4'>
          <instruction key='uninstall'>
            uninstallBundle(bundle:${artifact})
          </instruction>
          <instruction key='install'>
            installBundle(bundle:${artifact})
          </instruction>
          <instruction key='configure'>
            markStarted(started: true);
          </instruction>
          <instruction key='unconfigure'>
            markStarted(started: false);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolinggtk.linux.x86_64org.eclipse.equinox.common' version='1.0.0.202509081441' singleton='false'>
      <hostRequirements size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='3.18.200.v20231106-1826'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.x86_64org.eclipse.equinox.common' version='1.0.0.202509081441'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='toolinggtk.linux.x86_64' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='3.18.200.v20231106-1826'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
      </filter>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='4'>
          <instruction key='uninstall'>
            uninstallBundle(bundle:${artifact})
          </instruction>
          <instruction key='install'>
            installBundle(bundle:${artifact})
          </instruction>
          <instruction key='configure'>
            setStartLevel(startLevel:2);markStarted(started: true);
          </instruction>
          <instruction key='unconfigure'>
            setStartLevel(startLevel:-1);markStarted(started: false);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolinggtk.linux.x86_64org.eclipse.equinox.event' version='1.0.0.202509081441' singleton='false'>
      <hostRequirements size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.event' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.x86_64org.eclipse.equinox.event' version='1.0.0.202509081441'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='toolinggtk.linux.x86_64' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.event' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
      </filter>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='4'>
          <instruction key='uninstall'>
            uninstallBundle(bundle:${artifact})
          </instruction>
          <instruction key='install'>
            installBundle(bundle:${artifact})
          </instruction>
          <instruction key='configure'>
            setStartLevel(startLevel:2);markStarted(started: true);
          </instruction>
          <instruction key='unconfigure'>
            setStartLevel(startLevel:-1);markStarted(started: false);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolinggtk.linux.x86_64org.eclipse.equinox.simpleconfigurator' version='1.0.0.202509081441' singleton='false'>
      <hostRequirements size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.simpleconfigurator' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.x86_64org.eclipse.equinox.simpleconfigurator' version='1.0.0.202509081441'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='toolinggtk.linux.x86_64' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.simpleconfigurator' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
      </filter>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='4'>
          <instruction key='uninstall'>
            uninstallBundle(bundle:${artifact})
          </instruction>
          <instruction key='install'>
            installBundle(bundle:${artifact})
          </instruction>
          <instruction key='configure'>
            setStartLevel(startLevel:1);markStarted(started: true);
          </instruction>
          <instruction key='unconfigure'>
            setStartLevel(startLevel:-1);markStarted(started: false);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolingorg.eclipse.equinox.launcher' version='1.6.600.v20231106-1826' singleton='false'>
      <hostRequirements size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.launcher' range='[1.6.600.v20231106-1826,1.6.600.v20231106-1826]' greedy='false'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </hostRequirements>
      <properties size='2'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
        <property name='org.eclipse.pde.build.default' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.equinox.launcher' version='1.6.600.v20231106-1826'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='tooling' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.launcher' range='[1.6.600.v20231106-1826,1.6.600.v20231106-1826]' greedy='false'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='4'>
          <instruction key='uninstall'>
            uninstallBundle(bundle:${artifact});
          </instruction>
          <instruction key='install'>
            installBundle(bundle:${artifact});
          </instruction>
          <instruction key='configure'>
            addProgramArg(programArg:-startup);addProgramArg(programArg:@artifact);
          </instruction>
          <instruction key='unconfigure'>
            removeProgramArg(programArg:-startup);removeProgramArg(programArg:@artifact);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolingorg.eclipse.equinox.launcher.gtk.linux.x86_64' version='1.2.800.v20231003-1442' singleton='false'>
      <hostRequirements size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.launcher.gtk.linux.x86_64' range='[1.2.800.v20231003-1442,1.2.800.v20231003-1442]' greedy='false'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </hostRequirements>
      <properties size='2'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
        <property name='org.eclipse.pde.build.default' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.equinox.launcher.gtk.linux.x86_64' version='1.2.800.v20231003-1442'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='tooling' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.launcher.gtk.linux.x86_64' range='[1.2.800.v20231003-1442,1.2.800.v20231003-1442]' greedy='false'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
      </filter>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='4'>
          <instruction key='uninstall'>
            uninstallBundle(bundle:${artifact});
          </instruction>
          <instruction key='install'>
            installBundle(bundle:${artifact});
          </instruction>
          <instruction key='configure'>
            addProgramArg(programArg:--launcher.library);addProgramArg(programArg:@artifact);
          </instruction>
          <instruction key='unconfigure'>
            removeProgramArg(programArg:--launcher.library);removeProgramArg(programArg:@artifact);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
  </units>
  <iusProperties size='61'>
    <iuProperties id='eventbfileconverter.product' version='1.0.0.202509081441'>
      <properties size='2'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='eventbfileconverter.product_root.gtk.linux.x86_64' version='1.0.0.202509081441'>
      <properties size='1'>
        <property name='unzipped|@artifact|C:\Users\admin\Downloads\fileconverter\eclipse' value='C:\Users\admin\Downloads\fileconverter\eclipse\about.html|C:\Users\admin\Downloads\fileconverter\eclipse\eclipse|'/>
      </properties>
    </iuProperties>
  </iusProperties>
</profile>
